#include<stdio.h>
#include<stdlib.h>
#define Status int

//��������
typedef struct
{
	char ch;
}ElemType;

//���������
typedef struct BiNode
{
	BiNode *lchild;
	BiNode *rchild;
	ElemType data;
}BiNode,*BiTree;

//�������
typedef struct SNode
{
	SNode *next;
	BiTree data;
}SNode,*LinkStack;

//��ʼ�������
Status InitBiTree(BiTree &T)
{
	if(!T)
	{
		T = (BiNode *)malloc(sizeof(BiNode));
		T->lchild = T->rchild = NULL;
	}
	return 1;
}

//��ʼ��ջ���
Status InitStack(LinkStack &S)
{
	if(!S)
	{
		S = (SNode *)malloc(sizeof(SNode));
		S->next = NULL;
	}
	return 1;
}

//��ջ
Status Push(LinkStack &S,BiTree e)
{
	if(!S)
		return 0;
	SNode *p,*q;
	p = S;
	q = (SNode *)malloc(sizeof(SNode));
	q->data = e;
	q->next = p->next;
	p->next = q;
	return 1;
}

//��ջ
Status Pop(LinkStack &S,BiTree &e)
{
	if(!S || !S->next)
		return 0;
	SNode *p,*q;
	p = S;
	q = p->next;
	e = q->data;
	p->next = q->next;
	free(q);
	return 1;
}

//�жϿ�ջ
Status StackEmpty(LinkStack S)
{
	if(!S)
		return 0;
	if(!S->next)
		return 1;
	return 0;
}

//�ݹ齨����
Status CreatBiTree(BiTree &T)
{
	char ch;
	scanf("%c",&ch);
	if(ch == '*')
		T = NULL;
	else
	{
		InitBiTree(T);
		T->data.ch = ch;
		CreatBiTree(T->lchild);
		CreatBiTree(T->rchild);
	}
	return 1;
}

//�ǵݹ��������
Status PreOrderBiTree(BiTree T)
{
	if(!T)
		return 0;
	LinkStack S;
	S = NULL;
	InitStack(S);
	BiNode *p;
	p = T;
	while(p || !StackEmpty(S))
	{
		if(p)
		{
			printf("%4c",p->data);
			Push(S,p);
			p = p->lchild;
		}
		else
		{
			Pop(S,p);
			p = p->rchild;
		}
	}
	return 1;
}

//�ǵݹ��������
Status InOrderBiTree(BiTree T)
{
	if(!T)
		return 0;
	LinkStack S;
	S = NULL;
	InitStack(S);
	BiNode *p;
	p = T;
	while(p || !StackEmpty(S))
	{
		if(p)
		{
			Push(S,p);
			p = p->lchild;
		}
		else
		{
			Pop(S,p);
			printf("%4c",p->data);
			p = p->rchild;
		}
	}
	return 1;
}

//�ǵݹ�������
Status PostOrderBiTree(BiTree T)
{
	if(!T)
		return 0;
	LinkStack S1,S2;
	S1 = S2 = NULL;
	InitStack(S1);
	InitStack(S2);
	BiNode *p;
	p = T;
	while(p || !StackEmpty(S1))
	{
		if(p)
		{
			Push(S1,p);
			Push(S2,p);
			p = p->rchild;
		}
		else
		{
			Pop(S1,p);
			p = p->lchild;
		}
	}
	while(!StackEmpty(S2))
	{
		Pop(S2,p);
		printf("%4c",p->data);
	}
	return 1;
}


void main()
{
	BiTree T;
	T = NULL;
	printf(">>>Creating...\n");
	printf(">>>Input the BiNodes:\n");
	CreatBiTree(T);
	printf("PreOrderBiTree\t");
	PreOrderBiTree(T);
	printf("\n");
	printf("InOrderBiTree\t");
	InOrderBiTree(T);
	printf("\n");
	printf("PostOrderBiTree\t");
	PostOrderBiTree(T);
	printf("\n");
}