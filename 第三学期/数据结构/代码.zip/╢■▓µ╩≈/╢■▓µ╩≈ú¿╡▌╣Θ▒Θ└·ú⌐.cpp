#include<stdio.h>
#include<stdlib.h>
#define Status int

//��������
typedef struct
{
	char ch;
}ElemType;

//�������
typedef struct BiNode
{
	ElemType data;
	BiNode *lchild;
	BiNode *rchild;
}BiNode,*BiTree;

//��ʼ��������
Status InitBiTree(BiTree &T)
{
	if(!T)
	{
		T = (BiNode *)malloc(sizeof(BiNode));
		T->lchild = T->rchild = NULL;
	}
	return 1;
}

//�ݹ齨��������
Status CreatBiTree(BiTree &T)
{
	char ch;
	scanf("%c",&ch);
	if(ch == '*')
		T = NULL;
	else
	{
		InitBiTree(T);
		T->data.ch = ch;
		CreatBiTree(T->lchild);
		CreatBiTree(T->rchild);
	}
	return 0;
}

//�ݹ��������
Status PreOrderBiTree(BiTree &T)
{
	if(!T)
		return 0;
	printf("%4c",T->data.ch);
	PreOrderBiTree(T->lchild);
	PreOrderBiTree(T->rchild);
	return 1;
}

//�ݹ��������
Status InOrderBiTree(BiTree &T)
{
	if(!T)
		return 0;
	InOrderBiTree(T->lchild);
	printf("%4c",T->data.ch);
	InOrderBiTree(T->rchild);
	return 1;
}

//�ݹ�������
Status PostOrderBiTree(BiTree &T)
{
	if(!T)
		return 0;
	PostOrderBiTree(T->lchild);
	PostOrderBiTree(T->rchild);
	printf("%4c",T->data.ch);
	return 1;
}

void main()
{
	BiTree T;
	T = NULL;
	printf(">>>CreatBiTree...\n");
	printf("Input the BiNodes:\n");
	CreatBiTree(T);
	printf(">>>PreOrderBiTree\t");
	PreOrderBiTree(T);
	printf("\n");
	printf(">>>InOrderBiTree\t");
	InOrderBiTree(T);
	printf("\n");
	printf(">>>PostOrderBiTree\t");
	PostOrderBiTree(T);
	printf("\n");
}