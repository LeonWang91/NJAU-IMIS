#include<stdio.h>
#include<stdlib.h>
#define Status int

typedef struct
{
	int number;//ϵ��
	int power; // ����
}ElemType;

typedef struct LNode
{
	LNode *next;
	ElemType data;
}LNode,*LinkList;

Status InitList(LinkList &L)
{
	if(!L)
	{
		L = (LNode *)malloc(sizeof(LNode));
		L->next = NULL;
	}
	return 1;
}

Status InsertElem(LinkList &L,int i,ElemType e)
{
	if(!L)
		return 0;
	LNode *p;
	p = L;
	int j=0;
	while(p && j<i-1)
	{
		p = p->next;
		j++;
	}
	if(!p || i<=0)
		return 0;
	LNode *s = (LNode *)malloc(sizeof(LNode));
	s->data = e;
	s->next = p->next;
	p->next = s;
	return 1;
}

Status DeleteELem(LinkList &L,int i,ElemType &e)
{
	if(!L || !L->next)
		return 0;
	LNode *p;
	p = L;
	int j=0;
	while(p && j<i-1)
	{
		p = p->next;
		j++;
	}
	if(!p || i<=0)
		return 0;
	LNode *q;
	q = p->next;
	p->next = q->next;
	e = q->data;
	free(q);
	return 1;
}

Status GetElem(LinkList &L,int i,ElemType &e)
{
	if(!L || !L->next)
		return 0;
	LNode *p;
	p = L;
	int j=0;
	while(p && j<i)
	{
		p = p->next;
		j++;
	}
	if(!p || i<=0)
		return 0;
	e = p->data;
	return 1;
}

Status MergeList(LinkList La,LinkList Lb,LinkList &Lc)
{
	int label = 0;
	LNode *p1 = La->next;
	LNode *p2 = Lb->next;
	LNode *p3 = Lc = La;
	while(p1 && p2)
	{
		if(p1->data.power < p2->data.power)
		{
			p3->next = p1;
			p3 = p1;
			p1 = p1->next;
		}
		else if(p1->data.power > p2->data.power)
		{
			p3->next = p2;
			p3 = p2;
			p2 = p2->next;
		}
		else
		{
			p1->data.number = p1->data.number + p2->data.number;
			p3->next = p1;
			p3 = p1;
			p1 = p1->next;
			p2 = p2->next;
			label++;
		}
	}
	if(p1)
		p3->next = p1;
	else
		p3->next = p2;
	free(Lb);
	return label;
}

void main()
{
	LinkList La,Lb,Lc;
	La=Lb=Lc = NULL;
	InitList(La);
	InitList(Lb);
	InitList(Lc);
	int n1,n2;
	int num,pow;
	ElemType x,y,z;
	printf(">>>Input the number of NO.1 equation:\n");
	scanf("%d",&n1);
	printf(">>>Input the numbers and the powers of each of NO.1equation:");
	for(int i=1;i<=n1;i++)
	{
		printf("\n>>>number:");
		scanf("%d",&num);
		printf("\n>>>power:");
		scanf("%d",&pow);
		x.number = num;
		x.power = pow;
		InsertElem(La,i,x);
	}
	printf(">>>Input the number of NO.2 equation:\n");
	scanf("%d",&n2);
	printf(">>>Input the numbers and the powers of each of NO.2 equation:");
	for(int j=1;j<=n2;j++)
	{
		printf("\n>>>number:");
		scanf("%d",&num);
		printf("\n>>>power:");
		scanf("%d",&pow);
		y.number = num;
		y.power = pow;
		InsertElem(Lb,j,y);
	}
	printf("\n>>>Merging...\n");
	int n = MergeList(La,Lb,Lc);
	printf(">>>Input the NO.3 equation:\n");
	printf("number\t\tpower\t\t\n");
	for(int k=1;k<=n1+n2-n;k++)
	{
		GetElem(Lc,k,z);
		printf("%3d\t\t%3d\t\t\n",z.number,z.power);
	}
}