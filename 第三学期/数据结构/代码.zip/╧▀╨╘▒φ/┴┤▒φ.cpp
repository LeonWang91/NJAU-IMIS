#include<stdio.h>
#include<stdlib.h>
#define Status int

//��������
typedef struct
{
	int number;
}ElemType;

//�������
typedef struct LNode
{
	LNode *next;
	ElemType data;
	int Length;
}LNode,*LinkList;

//��ʼ������
Status InitList(LinkList &L)
{
	if(!L)
	{
		L = (LNode *)malloc(sizeof(LNode));
		L->next = NULL;
		L->Length=0;
		return 1;
	}
	return 0;
}

//������
Status InsertElem(LinkList &L,int i,ElemType e)
{
	LNode *p;
	int j=0;
	p = L; //ͷָ��
	while(p && j<i-1)
	{
		p = p->next; //�ӵ�һ�����������
		j++;
	}
	if(!p || i<=0) return 0;
	LNode *s = (LNode *)malloc(sizeof(LNode));
	s->data = e;
	s->next = NULL;
	s->next = p->next;
	p->next = s;
	L->Length++;
	return 1;
}

//ɾ�����
Status DeleteElem(LinkList &L,int i,ElemType &e)
{
	LNode *p,*q;
	int j=0;
	p = L;
	while(p && j<i-1)
	{
		p = p->next;
		j++;
	}
	if(!p || i<=0) return 0;
	q = p->next;
	p->next = q->next;
	e = q->data;
	free(q);
	L->Length--;
	return 1;
}

//���ҽ��
Status LocateList(LinkList L,ElemType e)
{
	if(!L)
		return 0;
	int i=0;
	LNode *p;
	p = L;
	while(p)
	{
		if(p->data.number != e.number)
		{
			p=p->next;
			i++;
		}
		else
			break
	}
	if(!p) return 0;
	return i;

}

//���ؽ��
Status GetElem(LinkList L,int i,ElemType &e)
{
//	if(!L || i<=0 || i>L->Length)
//		return 0;
	int j=0;
	LNode *p = L;
	while(p && j<i)
	{
		p = p->next;
		j++;
	}
	if(!p || i<=0)
	{
		return 0;
	}
	e = p->data;
	return e.number;
}

//��������
Status DestroyList(LinkList &L)
{
	if(!L)
		return 0;
	LNode *p,*q;
	p = L;
	while(p)
	{
		q = p->next;
		free(p);
		p = q;
	}
	return 1;
}

//�ϲ�����
Status MergeList(LinkList La,LinkList Lb,LinkList &Lc)
{
	LNode *p1 = La->next;
	LNode *p2 = Lb->next;
	LNode *p3;
//	Lc = (LNode)malloc(sizeof(LNode));
//	Lc->Length = La->Length + Lb->Length;
	Lc = La;  //��La��ͷ�����ΪLc��ͷ���
	p3 = Lc;
	while(p1 && p2)
	{
		if(p1->data.number <= p2->data.number)
		{
			p3->next = p1;
			p3 = p1;
			p1 = p1->next;
		}
		else
		{
			p3->next = p2;
			p3 = p2;
			p2 = p2->next;
		}
	}
	if(p1)
		p3->next = p1; //��һ�����涼������********
	else
		p3->next = p2;
	free(Lb);  //*************455555555555555555
	return 1;
}

//������
void main()
{
	LinkList L;
	L = NULL;
	InitList(L);
	int i;
	int num;
	ElemType e;
	ElemType a;
	printf(">>>Input:\n");
	for(i=1;i<4;i++)
	{
		scanf("%d",&num);
		e.number = num;
		InsertElem(L,i,e);
	}
	printf(">>>Searching...\n");
	a.number=2;
	printf("The position is NO.%d\n",LocateList(L,a));
	printf(">>>Deleteing...\n");
	DeleteElem(L,2,a);
	printf("The deleted elem is %d\n",a.number);
	LinkList La=NULL;
	InitList(La);
	LinkList Lb=NULL;
	InitList(Lb);
	LinkList Lc;
	printf(">>>Input La:\n");
	for(i=1;i<4;i++)
	{
		scanf("%d",&num);
		e.number = num;
		InsertElem(La,i,e);
	}
	printf(">>>Input Lb:\n");
	for(i=1;i<4;i++)
	{
		scanf("%d",&num);
		e.number = num;
		InsertElem(Lb,i,e);
	}
	printf("Mergeing...\n");
	MergeList(La,Lb,Lc);
	for(i=1;i<7;i++)
	{
		printf("The NO.%d number is %d\n",i,GetElem(Lc,i,e));
	}
	printf("\n");
	if(DestroyList(L))
		printf("Destory Successfully!\n");
}