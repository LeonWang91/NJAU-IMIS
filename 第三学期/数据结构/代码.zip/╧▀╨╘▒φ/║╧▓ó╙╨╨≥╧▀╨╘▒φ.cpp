#include<stdio.h>
#include<stdlib.h>
#define Status int
#define INIT_SIZE 20
#define LISTINCREMENT 10
#define N 10

//��������
typedef struct
{
	int number;
}ElemType;

//˳����洢�ṹ
typedef struct
{
	ElemType *pstu;
	int Length;
	int Listsize;
}SqList;

//��ʼ��˳���
Status InitList(SqList &L)
{
	if(!L.pstu)
	{
		L.pstu = (ElemType *)malloc(sizeof(ElemType) * INIT_SIZE);
		if(!L.pstu)
			return 0;  //����ʧ��******
		L.Length = 0;
		L.Listsize = INIT_SIZE;
		return 1;
	}
	return 0;
}

//�������
Status InsertList(SqList &L,int i,ElemType e)
{
	if(i<=0 || i>L.Length+1)
		return 0; //����λ�ó���
	if(L.Length>=L.Listsize)
	{
		ElemType *q;
		q = (ElemType *)realloc(L.pstu,sizeof(ElemType) * (LISTINCREMENT + INIT_SIZE));
		if(!q)
			return 0; //����ʧ��***
		L.Listsize = INIT_SIZE + LISTINCREMENT;
		L.pstu = q;  //���»���ַ
	}
	ElemType *m,*n;
	m = L.pstu+i-1;
	for(n=L.pstu+L.Length-1;n>=m;n--)
	{
		*(n+1) = *n;
	}
	*m = e;
	L.Length++; //����Ҫ����
	return 1;
}

//ɾ������
Status DeleteList(SqList &L,int i,ElemType &e)
{
	if(i<=0 || i>L.Length+1)
		return 0;
	ElemType *m,*n;
	m = L.pstu+i-1;
	for(n=m;n<L.pstu+L.Length;n++)
	{
		*n = *(n+1);
	}
	e = *m;
	L.Length--;
	return 1;
}

//�ж��Ƿ��ڱ���
int GetElem(SqList L,int i,int &e)
{
	ElemType *m;
	if(i<=0 || i>L.Length)
		printf("Error!");
	m = L.pstu+i-1;
	return m->number;
}

//�ҵ�λ��(�߼�λ��)
Status LocateList(SqList L,ElemType e)
{
	int i=0;
	ElemType *m;
	for(m=L.pstu;m<=L.pstu+L.Length-1;m++)
	{
		i++;
		if((*m).number == e.number)  //*****
		{
			return i;
		}
	}
	return 0;
}

//���ٱ�
Status DestoryList(SqList &L)
{
	if(!L.pstu)
		return 0;
	free(L.pstu);
	L.pstu = NULL;
	L.Length = 0;
	L.Listsize = INIT_SIZE;
	return 1;
}

//�ϲ�����˳���
Status MergeList(SqList La,SqList Lb,SqList &Lc)
{
	ElemType *p1 = La.pstu;
	ElemType *p2 = Lb.pstu;
	ElemType *p3 = Lc.pstu;
	Lc.Listsize=Lc.Length=La.Length + Lb.Length;  //***********
	while(p1<=(La.pstu+La.Length-1) && p2<=(Lb.pstu+Lb.Length-1))
	{
		if(p1->number <= p2->number)
		{
			*p3++ = *p1++;
		}
		else
		{
			*p3++ = *p2++;
		}
	}
	while(p1<=La.pstu+La.Length-1)
	{
		*p3++ = *p1++;
	}
	while(p2<=Lb.pstu+Lb.Length-1)
	{
		*p3++ = *p2++;
	}
	return 1;
}

//������
void main()
{
	SqList L;
	L.pstu = NULL;
	InitList(L);
	ElemType num,e;
	ElemType a;
	printf("����˳���...\n");
	for(int i=1;i<=3;i++)
	{
		scanf("%d",&num.number);
		InsertList(L,i,num);
	}
	printf("ɾ����һ��Ԫ��\n");
	DeleteList(L,1,e);
	printf("�ҵ�Ԫ��a\n");
	printf("��λ...\n");
	int j;
	a.number = 1;
	j = LocateList(L,a);
	printf("%d\n",j);

	//�ϲ����Ա�
	SqList La,Lb,Lc;
	La.pstu = NULL;
	Lb.pstu = NULL;
	Lc.pstu = NULL;
	InitList(La);
	printf("����˳���...\n");
	for(i=1;i<=3;i++)
	{
		scanf("%d",&num.number);
		InsertList(La,i,num);
	}
	InitList(Lb);
	printf("����˳���...\n");
	for(i=1;i<=3;i++)
	{
		scanf("%d",&num.number);
		InsertList(Lb,i,num);
	}
	InitList(Lc);
	printf("Merging...\n");
	MergeList(La,Lb,Lc);
	int x;
	for(i=1;i<=6;i++)
	{
		printf("The NO.%d is %d\n",i,GetElem(Lc,i,x));
	}
}