#include<stdio.h>
#include<stdlib.h>
#define Status int

//��������
typedef struct
{
	int number;
}ElemType;

//�������
typedef struct LNode
{
	LNode *next;
	ElemType data;
	int Length;
}LNode,*LinkList;

//��ʼ������
Status InitList(LinkList &L)
{
	if(!L)
	{
		L = (LNode *)malloc(sizeof(LNode));
		L->next = NULL;
		L->Length=0;
		return 1;
	}
	return 0;
}

//������
Status InsertElem(LinkList &L,int i,ElemType e)
{
	LNode *p;
	int j=0;
	p = L;
	while(p && j<i-1)
	{
		p = p->next;
		j++;
	}
	if(!p || i<=0) return 0;
	LNode *s = (LNode *)malloc(sizeof(LNode));
	s->data = e;
	s->next = p->next;
	p->next = s;
	L->Length++;
	return 1;
}

//ɾ�����
Status DeleteElem(LinkList &L,int i,ElemType &e)
{
	LNode *p,*q;
	int j=0;
	p = L;
	while(p && j<i-1)
	{
		p = p->next;
		j++;
	}
	if(!p || i<=0) return 0;
	q = p->next;
	p->next = q->next;
	e = q->data;
	free(q);
	L->Length--;
	return 1;
}

//Ѱ�ҽ��
Status LocateList(LinkList L,ElemType e)
{
	if(!L)
		return 0;
	int i=0;
	LNode *p;
	p = L;
	while(p)
	{
		if(p->data.number != e.number)
		{
			p=p->next;
			i++;
		}
		else
			break;
	}
	if(!p) return 0;
	return i;

}

//���ؽ��
ElemType GetElem(LinkList L,int i,ElemType &e)
{
	int j=0;
	LNode *p = L;
	while(p && j<i)
	{
		p = p->next;
		j++;
	}
	if(!p || i<=0)
	{
		printf("Error!");
	}
	e = p->data;
	return e;
}

//��������
Status DestroyList(LinkList &L)
{
	if(!L)
		return 0;
	LNode *p,*q;
	p = L;
	while(p)
	{
		q = p->next;
		free(p);
		p = q;
	}
	return 1;
}

//�ϲ�����
Status MergeList(LinkList La,LinkList Lb,LinkList &Lc)  //���뵽�½��ı�c��
{
	InitList(Lc); 
	int i=1,j=1,k=0;//k��ʾ����c���е�λ��
	ElemType a,b;
	while(i<=La->Length && j<=Lb->Length)
	{
		GetElem(La,i,a);
		GetElem(Lb,j,b);
		if(a.number <= b.number)
		{
			InsertElem(Lc,++k,a);  //��С�ķŵ���c���棬�������Ҹñ��е���һ��Ԫ����b�Ƚ�
			i++;
		}
		else
		{
			InsertElem(Lc,++k,b);
			j++;
		}
	}
	while(i<=La->Length)
	{
		GetElem(La,i,a);
		InsertElem(Lc,++k,a);
		i++;
	}
	while(j<=Lb->Length)
	{
		GetElem(Lb,j,b);
		InsertElem(Lc,++k,b);
		j++;
	}
	return 1;
}

//������
void main()
{
	LinkList L;
	L = NULL;
	InitList(L);
	int i;
	int num;
	ElemType e;
	ElemType a;
	printf(">>>Input:\n");
	for(i=1;i<4;i++)
	{
		scanf("%d",&num);
		e.number = num;
		InsertElem(L,i,e);
	}
	printf(">>>Searching...\n");
	a.number=2;
	printf("The position is NO.%d\n",LocateList(L,a));
	printf(">>>Deleteing...\n");
	DeleteElem(L,2,a);
	printf("The deleted elem is %d\n",a.number);
	LinkList La=NULL;
	InitList(La);
	LinkList Lb=NULL;
	InitList(Lb);
	LinkList Lc=NULL;
	printf(">>>Input La:\n");
	for(i=1;i<4;i++)
	{
		scanf("%d",&num);
		e.number = num;
		InsertElem(La,i,e);
	}
	printf(">>>Input Lb:\n");
	for(i=1;i<4;i++)
	{
		scanf("%d",&num);
		e.number = num;
		InsertElem(Lb,i,e);
	}
	printf("Mergeing...\n");
	MergeList(La,Lb,Lc);
	ElemType x;
	for(i=1;i<7;i++)
	{
		x = GetElem(Lc,i,e);
		printf("The NO.%d number is %d\n",i,x.number);
	}
	printf("\n");
}