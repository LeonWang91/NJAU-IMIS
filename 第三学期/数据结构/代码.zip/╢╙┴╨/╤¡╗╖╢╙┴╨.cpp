#include<stdio.h>
#include<stdlib.h>
#define Status int
#define QUEUE_INIT_SIZE 100
#define QUEUEINCREMENT 10

//��������
typedef struct
{
	int number;
}ElemType;

//�洢����
typedef struct
{
	ElemType *base;
	int front;
	int rear;
	int QueueSize;
}SqQueue;

//��ʼ������
Status InitQueue(SqQueue &Q)
{
	if(!Q.base)
	{
		Q.base = (ElemType *)malloc(sizeof(ElemType)*QUEUE_INIT_SIZE);
		if(!Q.base)
			return 0;
		Q.front = Q.rear = 0;
		Q.QueueSize = QUEUE_INIT_SIZE;
	}
	return 1;
}

//����Ԫ�ص���β
Status EnQueue(SqQueue &Q,ElemType e)
{
	if(!Q.base)
		return 0;
	if((Q.rear+1)%QUEUE_INIT_SIZE == Q.front) //******************
	{
		Q.base = (ElemType *)realloc(Q.base,sizeof(ElemType)*(QUEUE_INIT_SIZE + QUEUEINCREMENT));
		if(!Q.base)
			return 0;
		Q.rear = Q.front + Q.QueueSize;
		Q.QueueSize += QUEUEINCREMENT;
	}
	Q.base[Q.rear] = e;
	Q.rear = (Q.rear+1)%QUEUE_INIT_SIZE;//*******************
	return 1;
}

//ɾ����ͷԪ��
Status DeQueue(SqQueue &Q,ElemType &e)
{
	if(!Q.base)
		return 0;
	e = Q.base[Q.front];
	Q.front = (Q.front+1)%QUEUE_INIT_SIZE;//****************
	return 1;
}

//�ҵ���ͷԪ��
Status GetHead(SqQueue Q,ElemType &e)
{
	if(!Q.base)
		return 0;
	e = Q.base[Q.front];
	return 1;
}

//�ݻٶ���
Status DestoryQueue(SqQueue &Q)
{
	if(!Q.base)
		return 0;
	free(Q.base);
	Q.base = NULL;
	Q.front = Q.rear = 0;
	Q.QueueSize = 0;
	return 1;
}

//����г���
Status QueueLength(SqQueue &Q)
{
	if(!Q.base)
		return 0;
	return((Q.rear-Q.front)%QUEUE_INIT_SIZE);
}

void main()
{
	SqQueue Q;
	Q.base = NULL;
	InitQueue(Q);
	int num;
	ElemType x,y,z;
	printf(">>>Insert:\n");
	for(int i=0;i<3;i++)
	{
		scanf("%d",&num);
		x.number = num;
		EnQueue(Q,x);
	}
	printf(">>>GetHead:\n");
	GetHead(Q,y);
	printf("%d\n",y.number);
	printf(">>>Delete:\n");
	DeQueue(Q,z);
	printf("%d\n",z.number);
	printf(">>>Length:\n");
	printf("%d\n",QueueLength(Q));
	if(DestoryQueue(Q))
		printf("Destory Successfully!\n");
}