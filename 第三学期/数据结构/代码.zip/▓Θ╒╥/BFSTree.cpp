#include<stdio.h>
#include<stdlib.h>
#define N 7
#define Status int 

//������������
typedef struct TNode
{
	int key;
	TNode *lchild,*rchild;
}TNode,*BSTree;

//��ʼ��BFSTree
Status InitBSFTree(BSTree &T)
{
	if(!T)
	{
		T=(TNode *)malloc(sizeof(TNode));
		T->lchild = T->rchild = NULL;
		T->key = 0;
	}
	return 1;
}
 
//���Ҷ���������
Status SearchBST(BSTree &T,int key,BSTree &p,BSTree &f)  //��ָ�벻����ģ��Ժ󶼴����ã�����
{
	if(!T)
	{
		p = f;
		return 0;//��Ҫ����
	}
	else if(T->key == key)
	{
		p = T;
		return 1;//�������
	}
	else if(T->key > key)
	{
		return(SearchBST(T->lchild,key,p,T));
	}
	else
	{
		return(SearchBST(T->rchild,key,p,T));
	}
	return 0;
}


//����Ԫ��
Status InsertBST(BSTree &T,int key,BSTree &p,BSTree &f)
{
	TNode *s;
	if(!SearchBST(T,key,p,f))
	{
		s = (TNode *)malloc(sizeof(TNode));
		s->lchild = s->rchild = NULL;
		s->key = key;
		if(!p)//ֻ�е�һ��f == NULL;
		{
			T = s;
		}
		else if(p->key > key)
		{
			p->lchild = s;
		}
		else if(p->key < key)
		{
			p->rchild = s;
		}
		return 1;
	}
	else
		return 0;
	
}

//�������
Status PreOrderTraverse(BSTree T)
{
	if(!T)
		return 0;
	printf("%4d",T->key);
	PreOrderTraverse(T->lchild);
	PreOrderTraverse(T->rchild);
	return 1;
}

//�������
Status InOrderTraverse(BSTree T)
{
	if(!T)
		return 0;
	InOrderTraverse(T->lchild);
	printf("%4d",T->key);
	InOrderTraverse(T->rchild);
	return 1;
}

//�������
Status PostOrderTraverse(BSTree T)
{
	if(!T)
		return 0;
	PostOrderTraverse(T->lchild);
	PostOrderTraverse(T->rchild);
	printf("%4d",T->key);
	return 1;
}

//������
Status main()
{
	int i,key;
	BSTree T;
	TNode *p,*f;
	T=NULL;
	p=f=NULL;
	//InitBSFTree(T);
	int array[N] = {2,19,7,1,45,33,21};
	printf(">>>Input the key...\n");
	for(i=0;i<N;i++)
	{
		key = array[i];	
		InsertBST(T,key,p,f); 
	}
	printf(">>>Input Finished!\n");
	printf("\n>>>PreOrderTraverse\n");
	PreOrderTraverse(T);
	printf("\n");
	printf("\n>>>InOrderTraverse\n");
	InOrderTraverse(T);
	printf("\n");
	printf("\n>>>PostOrderTraverse\n");
	PostOrderTraverse(T);
	printf("\n");
	return 1;
} 


