#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define MaxRoom 15
#define N 12
#define Status int

//��������
typedef struct HNode{
	int elem;
	HNode *next;
}HNode,*LinkList;


//����ͷ���
typedef struct{
	int site;
	HNode *firstnode; 
}HaNode,HaArray[MaxRoom];


//����һ����ϣ��
typedef struct{
	int count;
	HaArray array;
}HashTable;


//����ؼ�ֵ
Status InsertHash(HashTable &H,int key)
{
	HNode *p,*q;
	int position = 0;
	int remainder = key % (N+1);
	if(!H.array[remainder].firstnode) //��ʼ��ͷ���
	{
		p = (HNode *)malloc(sizeof(HNode));
		p->elem = key;
		p->next = H.array[remainder].firstnode;
		H.array[remainder].firstnode = p;
		position++;
	}
	else
	{
		//p = (HNode *)malloc(sizeof(HNode));
		p = H.array[remainder].firstnode;
		q = (HNode *)malloc(sizeof(HNode));
		while(p->next)
		{
			position++;
			p = p->next;
		}
		q->elem = key;
		q->next = p->next;
		p->next = q;
		position++;
	}
	printf("\n>>>The key has been insert at No.%d in Array[%d]!\n",position,remainder);
	return 1;
}


//���ҹ�ϣ�� 
Status SearchHash(HashTable &H,int key)
{
	HNode *p;
	int position = 0;
	int remainder = key % (N+1);
	for(int i=0;i<MaxRoom;i++)
	{
		p = H.array[i].firstnode;
		if(remainder == H.array[i].site)
		{
			while(p)
			{
				position++;
				if(p->elem == key)
				{
					printf("\n>>>The key has been found at No.%d in Array[%d]!\n",position,H.array[i].site);
					break;
				}
				p = p->next;
			}
			if(p->elem == key)
			{
				break;
			}
		}
	}
	if(!p)  //pΪ�գ�24������Ҫ�������
	{
		printf("\n>>>The key has not been found in HashTable!\n\n");
		printf("\n>>>Insert the key in the HashTable:\n");
		InsertHash(H,key);
		printf("\n>>>Insert Successfully!\n");
	} 
	return 1;
}


//������ϣ��
Status CreatHash(HashTable &H)
{
	HNode *p,*q;
	int remainder[N];
	int hashsize[N] = {19,14,23,01,68,20,84,27,55,11,10,79};
	for(int i=0;i<MaxRoom;i++)
	{
		H.array[i].site = i;
		H.array[i].firstnode = NULL;
		H.count = 0;
	}
	for(int j=0;j<N;j++)
	{
		remainder[j] = hashsize[j] % (N+1);
		for(int i=0;i<MaxRoom;i++)
		{
			if(remainder[j]==H.array[i].site)
			{
				if(H.array[i].firstnode == NULL) //ͷ���Ϊ�� 
				{
					p = (HNode *)malloc(sizeof(HNode));
					p->elem = hashsize[j];
					p->next = H.array[i].firstnode;
					H.array[i].firstnode = p;
				}
				else  //ͷ��㲻Ϊ�� 
				{
					q = (HNode *)malloc(sizeof(HNode));
					p = H.array[i].firstnode;
					while(p->next)
					{
						p = p->next;
					}
					q->elem = hashsize[j];
					q->next = p->next;
					p->next = q;
				}
				H.count++;
				break; 
			}
		}
	}
	return 1;
}


//������ 
Status main()
{
	int i,key;
	HNode *p;
	HashTable H;

	//������ϣ��
	printf(">>>Creating HashTable...\n"); 
	CreatHash(H);
	printf("\n>>>The HashTable has been Created!\n");
	printf("\nThe HashTable has %d keys\n",H.count);

	//���ԭʼ��ϣ��
	printf("\n>>>>>>Original HashTable<<<<<<\n");
	for(i=0;i<MaxRoom;i++)
	{
		p = H.array[i].firstnode;
		printf("%d\t",H.array[i].site);
		while(p)
		{
			printf("%d\t",p->elem);
			p = p->next;
		}
		printf("\n");
	}
	printf("\n");

	//����
	printf("\n>>>Input the key you want to search:");
	scanf("%d",&key);
	printf("\n>>>Start to search it...\n");
	SearchHash(H,key);

	//������չ�ϣ��
	printf("\n>>>>>>Present HashTable<<<<<<\n");
	for(i=0;i<MaxRoom;i++)
	{
		p = H.array[i].firstnode;
		printf("%d\t",H.array[i].site);
		while(p)
		{
			printf("%d\t",p->elem);
			p = p->next;
		}
		printf("\n");
	}
	printf("\n");
	printf("\n********Finished!********\n"); 
	return 1;
}
