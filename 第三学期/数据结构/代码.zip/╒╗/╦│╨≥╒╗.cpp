#include<stdio.h>
#include<stdlib.h>
#define Status int
#define STACK_SIZE 100
#define STACKINCREMENT 10

//��������
typedef struct
{
	int number;
}ElemType;

//�洢����
typedef struct
{
	ElemType *base;
	ElemType *top;
	int StackSize;
}SqStack;

//��ʼ��˳��ջ
Status InitStack(SqStack &S)
{
	if(!S.base)
	{
		S.base = (ElemType *)malloc(sizeof(ElemType)*STACK_SIZE);
		if(S.base)
			return 0; //**�洢����ʧ��
		S.top = S.base;
		S.StackSize = STACK_SIZE;
		return 1;
	}
	return 0;
}

//����Ԫ��
Status Push(SqStack &S,ElemType e)
{
	if(!S.base)
		return 0;
	if(S.top >= S.base+S.StackSize)
	{
		S.base = (ElemType *)realloc(S.base,sizeof(ElemType) * (STACK_SIZE + STACKINCREMENT));
		S.top = S.base + S.StackSize;
		S.StackSize = S.StackSize + STACKINCREMENT;
	}
	*S.top++ = e;
	return 1;
}

//ɾ��ջ��Ԫ��
Status Pop(SqStack &S,ElemType &e)
{
	if(!S.base || S.base == S.top)
		return 0;
	e = *(--S.top);//****************************************������
	return 1;
}

//ȡջ��Ԫ��
Status GetTop(SqStack &S,ElemType &e) 
{
	if(!S.base || S.base == S.top)
		return 0;
	e = *(S.top-1);  //**************************************������
	return 1;
}

//�ÿ�ջ
Status ClearStack(SqStack &S)
{
	if(!S.base || S.base == S.top)
		return 0;
	S.base = S.top;
	return 1;
}

//�Ƿ�Ϊ��ջ
Status StackEmpty(SqStack &S)
{
	if(!S.base)
		return 0;
	if(S.base == S.top)
		return 1;
	return 0;
}

//�ݻ�ջ
Status DeStoryStack(SqStack &S)
{
	if(!S.base)
		return 0;
	S.base = S.top = NULL;  //**********�ָ���������
	free(S.base);          //ָ�����Ҫfree
	S.StackSize = 0;
	return 1;
}

void main()
{
	SqStack S;
	S.base = NULL;
	InitStack(S);
	int num;
	ElemType x,y;
	printf(">>>Input:\n");
	for(int i=0;i<3;i++)
	{
		scanf("%d",&num);
		x.number = num;
		Push(S,x);
	}
	printf(">>>POP:\n");
	Pop(S,y);
	printf("%d\n",y.number);
	printf(">>>GetTop:\n");
	GetTop(S,y);
	printf("%d\n",y.number);
	ClearStack(S);
	if(StackEmpty(S))
		printf("It is a null stack!\n");
}