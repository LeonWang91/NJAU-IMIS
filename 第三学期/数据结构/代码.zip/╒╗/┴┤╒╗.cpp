#include<stdio.h>
#include<Stdlib.h>
#define Status int

//��������
typedef struct
{
	int number;
}ElemType;

//�������
typedef struct LNode
{
	LNode *next;
	ElemType data;
}LNode,*LinkList;

//��ʼ������
Status InitStack(LinkList &S)
{
	if(!S)
	{
		S = (LNode *)malloc(sizeof(LNode));
		S->next = NULL;
	}
	return 1;
}

//������
Status Push(LinkList &S,ElemType e)
{
	if(!S)
		return 0;
	LNode *p = S;
	LNode *q = (LNode *)malloc(sizeof(LNode));
	q->data = e;
	q->next = NULL;
	q->next = p->next;
	p->next = q;
	return 1;
}

//ɾ��ջ�����
Status Pop(LinkList &S,ElemType &e)
{
	if(!S && !S->next)
		return 0;
	LNode *p = S;
	LNode *q;
	q = p->next;  //********ע��������ջ��Ԫ����S->next
	e = q->data;
	p->next = q->next;
	free(q);
	return 1;
}

//ȡջ��Ԫ��
Status GetTop(LinkList &S,ElemType &e)
{
	if(!S && !S->next)
		return 0;
	e = S->next->data;  //*******������ջ��Ԫ����S->next
	return 1;
}

//�ÿ�ջ
Status ClearStack(LinkList &S)
{
	if(!S || !S->next)
		return 0;
	S->next = NULL;
	return 1;
}

//�ж��Ƿ�Ϊ��ջ
Status StackEmpty(LinkList &S)
{
	if(!S)
		return 0;
	if(!S->next)
		return 1;
	return 0;
}

//�ݻ�ջ
Status DestroyStack(LinkList &S)
{
	if(!S)
		return 0;
	LNode *p,*q;
	p = S;
	while(p)
	{
		q = p->next;
		free(p);
		p = q;
	}
	return 1;
}

void main()
{
	LinkList S;
	S = NULL;
	InitStack(S);
	ElemType x,y;
	int num;
	printf(">>>Input:\n");
	for(int i=0;i<=3;i++)
	{
		scanf("%d",&num);
		x.number = num;
		Push(S,x);
	}
	printf(">>>Pop:\n");
	Pop(S,y);
	printf("%d\n",y.number);
	printf(">>>GetTop:\n");
	GetTop(S,y);
	printf("%d\n",y.number);
	//ClearStack(S);
	if(StackEmpty(S))
		printf("It is a null stack!\n");
	if(DestroyStack(S))
		printf("Destory Successfully!\n");
}