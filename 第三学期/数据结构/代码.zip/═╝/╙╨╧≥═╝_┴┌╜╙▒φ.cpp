#include<stdio.h>
#include<stdlib.h>
#define Status int
#define MAX_VERTEX_NUM 20

//�����
typedef struct ArcNode
{
	char arcdata;
	ArcNode *next;
}ArcNode;

//ͷ���
typedef struct
{
	char vexname;
	ArcNode *firstarc;//ָ���һ�������
	int InDegree;
	int OutDegree;
}VexNode,VList[MAX_VERTEX_NUM];

//ͼ�Ĵ洢����
typedef struct
{
	VList vexs;  //ͷ�������
	int vexnum,arcnum;
}AlGraph;

//��λ
Status LocateVex(AlGraph G,char v)
{
	for(int i=0;i<G.vexnum;i++)
	{
		if(G.vexs[i].vexname == v)
			break;
	}
	return i;
}

//�������������γ�ͼ
Status CreatGraph(AlGraph &G)
{
	char v,u;
	int i,m,n;
	printf(">>>Input the number of vexnum:");
	scanf("%d",&G.vexnum);
	printf(">>>Input the number of arcnum:");
	scanf("%d",&G.arcnum);
	getchar();
	//��ʼ���������ϵ�ÿһ��ͷ���
	for(i=0;i<G.vexnum;i++)
	{
		printf(">>>Input the No.%d vexname:",i+1);
		scanf("%c",&G.vexs[i].vexname);
		getchar();
		G.vexs[i].firstarc = NULL;
		G.vexs[i].InDegree = 0;
		G.vexs[i].OutDegree = 0;
	}
	//�����в�������
	for(i=0;i<G.arcnum;i++)  //ѭ����ֹ����ȡ������صĻ���
	{
		printf(">>>Input v&u(v->u):");
		scanf("%c->%c",&v,&u);
		getchar();
		m = LocateVex(G,v);
		n = LocateVex(G,u);
		ArcNode *p = (ArcNode *)malloc(sizeof(ArcNode));
		p->arcdata = u;
		p->next = G.vexs[m].firstarc;
		G.vexs[m].firstarc = p;
		G.vexs[m].OutDegree++;
		G.vexs[n].InDegree++;
	}
	printf(">>>OutDegree as follow:\n");
	printf("Vexs\tOutDegree\tInDegree\n");
	for(i=0;i<G.vexnum;i++)
	{
		printf("%3c\t%3d\t\t%3d\n",G.vexs[i].vexname,G.vexs[i].OutDegree,G.vexs[i].InDegree);
	}
	return 1;
}

void main()
{
	int i;
	ArcNode *p;
	AlGraph G;
	printf(">>>CreatGraph\n");
	CreatGraph(G);
	printf(">>>AdjList as follows\n");
	for(i=0;i<G.vexnum;i++)
	{
		printf("%c\t",G.vexs[i].vexname);
		p = G.vexs[i].firstarc;
		while(p)
		{
			printf("%c\t",p->arcdata);
			p = p->next;
		}
		printf("\n");
	}
}