#include<stdio.h>
#include<stdlib.h>
#define Status int
#define MAX_VERTEX_NUM 20

typedef struct ArcNode
{
	int adj; //�����е�Ԫ��
}ArcNode,AdjMatrix[MAX_VERTEX_NUM][MAX_VERTEX_NUM];

typedef struct
{
	AdjMatrix arcs;
	char vexs[MAX_VERTEX_NUM];
	int vexnum,arcnum;
}MGraph;

Status LocateVex(MGraph G,char v)
{
	for(int i=0;i<G.vexnum;i++)
	{
		if(G.vexs[i]==v)
			break;
	}
	return i;
}

Status CreatGraph(MGraph &G)
{
	int i,j;
	int InDegree[MAX_VERTEX_NUM],OutDegree[MAX_VERTEX_NUM];
	char ch,v1,v2;
	//ȷ��������ͱ���
	printf(">>>Input the number of vexnum:");
	scanf("%d",&G.vexnum);
	printf(">>>Input the number of arcnum:");
	scanf("%d",&G.arcnum);
	getchar();
	//ȷ�������Ϣ
	for(i=0;i<G.vexnum;i++)
	{
		printf(">>>Input the No.%d vexname:",i+1);
		scanf("%c",&G.vexs[i]);
		getchar();
	}
	//��ʼ���ڽӾ���
	for(i=0;i<G.vexnum;i++)
	{
		for(j=0;j<G.vexnum;j++)
		{
			G.arcs[i][j].adj = 0;
		}
	}
	//�����ڽӵ㲢������ڽӾ���
	do
	{
		printf(">>>Input one of the vexs:");
		scanf("%c",&v1);
		getchar();
		printf(">>>Input the other vex:");
		scanf("%c",&v2);
		getchar();
		i = LocateVex(G,v1);
		j = LocateVex(G,v2);
		G.arcs[i][j].adj = 1;
	}while((ch = getchar())!='*');
	//��ʼ���ȵ�����
	for(i=0;i<G.vexnum;i++)
	{
		InDegree[i] = 0;
		OutDegree[i] = 0;
	}
	//����ÿ�����Ķ�
	printf(">>>Degree as follows:\n");
	printf("Vexs\tOutDegree\n");
	for(i=0;i<G.vexnum;i++)
	{
		for(j=0;j<G.vexnum;j++)
		{
			if(G.arcs[i][j].adj == 1)//������������
			{
				OutDegree[i]++;
			}
		}
		printf("%3c\t%3d\n",G.vexs[i],OutDegree[i]);
	}
	printf("\n");
	printf("Vexs\tInDegree\n");
	for(i=0;j<G.vexnum;j++)
	{
		for(j=0;i<G.vexnum;i++)
		{
			if(G.arcs[j][i].adj == 1)//������������
			{
				InDegree[j]++;
			}
		}
		printf("%3c\t%3d\n",G.vexs[j],InDegree[j]);
	}
	return 1;
}

void main()
{
	MGraph G;
	printf(">>>CreatGraph\n");
	CreatGraph(G);
	printf(">>>ArcMatrix as follow:\n");
	for(int i=0;i<G.vexnum;i++)
	{
		for(int j=0;j<G.vexnum;j++)
		{
			printf("%3d",G.arcs[i][j].adj);
		}
		printf("\n");
	}
}