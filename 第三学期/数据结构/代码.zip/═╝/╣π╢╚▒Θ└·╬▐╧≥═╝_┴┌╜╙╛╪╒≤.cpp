#include<stdio.h>
#include<stdlib.h>
#define Status int
#define MAX_VERTEX_NUM 20

//��������
typedef int ElemType;

//�����н��
typedef struct QNode
{
	ElemType data;
	QNode *next;
}QNode,*QueuePtr;

//ָ��ṹ��
typedef struct
{
	QNode *front;
	QNode *rear;
}LinkQueue;

//�ڽӾ������ڽ���Ϣ
typedef struct
{
	int adj;
}ArcNode,AdjMatrix[MAX_VERTEX_NUM][MAX_VERTEX_NUM];

//����ͼ�Ĵ洢�ṹ
typedef struct
{
	AdjMatrix arcs;
	char vexs[MAX_VERTEX_NUM];
	int vexnum,arcnum;
}MGraph;

//��ʼ������
Status InitQueue(LinkQueue &Q)
{
	if(!Q.front && !Q.rear)
	{
		Q.front = Q.rear = (QNode *)malloc(sizeof(QNode));
		Q.front->next = NULL;
		Q.rear->next = NULL;
	}
	return 1;
}

Status EnQueue(LinkQueue &Q,ElemType e)
{
	if(!Q.front && !Q.rear)
		return 0;
	QNode *p;
	p = (QNode *)malloc(sizeof(QNode));
	p->data = e;
	p->next = NULL;//************
	Q.rear->next = p;
	Q.rear = p;	
	return 1;
}

Status DeQueue(LinkQueue &Q,ElemType &e)
{
	if(!Q.front && !Q.rear && Q.front == Q.rear)
		return 0;
	QNode *p;
	p = Q.front->next;
	e = p->data;
	Q.front->next = p->next;//****
	if(Q.rear == p)//****************ע��λ�ù�ϵ
		Q.rear = Q.front;//*******
	free(p);
	return 1;
}

Status QueueEmpty(LinkQueue Q)
{
	if(!Q.front && !Q.rear)
		return 0;
	if(Q.front == Q.rear)
		return 1;
	return 0;
}

Status LocateVex(MGraph G,char v)
{
	for(int i=0;i<G.vexnum;i++)
	{
		if(G.vexs[i] == v)
		{
			break;
		}
	}
	return i;
}

Status CreatGraph(MGraph &G) 
{
	char ch;
	int i,j;
	char v1,v2;
	int degree[MAX_VERTEX_NUM];
	printf(">>>Input the number of vexnum:");
	scanf("%d",&G.vexnum);
	printf(">>>Input the number of arcnum:");
	scanf("%d",&G.arcnum);
	getchar();
	for(i=0;i<G.vexnum;i++)
	{
		printf(">>>Input NO.%d verx:",i+1);
		scanf("%c",&G.vexs[i]);
		getchar();
		for(j=0;j<G.vexnum;j++)
		{
			G.arcs[i][j].adj = 0;  //******************.adj
			degree[i] = 0;
		}
	}
	do
	{
		printf(">>>Input one of the vexs:");
		scanf("%c",&v1);
		getchar();
		printf(">>>Input the other vex:");
		scanf("%c",&v2);
		getchar();
		i = LocateVex(G,v1);
		j = LocateVex(G,v2);
		G.arcs[i][j].adj = 1;
		G.arcs[j][i] = G.arcs[i][j];
	}while((ch = getchar()) != '*');
	printf(">>>Degree as follows:\n");
	printf("Vexs\tDegree\n");
	for(i=0;i<G.vexnum;i++)
	{
		for(j=0;j<G.vexnum;j++)
		{
			if(G.arcs[i][j].adj == 1)
			{
				degree[i]++;
			}
		}
		printf("%3c\t%3d\n",G.vexs[i],degree[i]);
	}
	return 1;
}

Status BFSTraverse(MGraph G)
{
	int i,j,k;
	LinkQueue Q;
	Q.front = NULL;
	Q.rear = NULL;
	InitQueue(Q);
	bool visit[MAX_VERTEX_NUM];
	for(i=0;i<G.vexnum;i++)
	{
		visit[i] = false;
	}
	for(k=0;k<G.vexnum;k++)
	{
		if(!visit[k])
		{
			EnQueue(Q,k);
			visit[k] = true;
			while(!QueueEmpty(Q))
			{
				DeQueue(Q,i);
				printf("%4c",G.vexs[i]);
				for(j=0;j<G.vexnum;j++)
				{
					if(G.arcs[i][j].adj == 1 && !visit[i])
					{
						EnQueue(Q,j);
						visit[j] = true;
					}
				}
			}
		}
	}
	printf("\n");
	return 1;
}

void main()
{
	MGraph G;
	printf(">>>CreatGraph\n");
	CreatGraph(G);//��������δ��&����ᱨ��˵Gδ���壡
	printf(">>>The AdjMatrix as follows:\n");
	for(int i=0;i<G.vexnum;i++)
	{
		for(int j=0;j<G.vexnum;j++)
		{
			printf("%3d",G.arcs[i][j]);
		}
		printf("\n");
	}
	printf(">>>BFSTraverse:\n");
	BFSTraverse(G);
}