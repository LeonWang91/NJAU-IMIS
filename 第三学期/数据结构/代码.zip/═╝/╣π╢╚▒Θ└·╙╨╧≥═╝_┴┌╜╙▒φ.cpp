#include<stdio.h>
#include<stdlib.h>
#define Status int
#define MAX_VERTEX_NUM 20

typedef int ElemType;

//�����
typedef struct ArcNode
{
	int pos;
	char arcdata;
	ArcNode *next;
}ArcNode;

//ͷ���
typedef struct
{
	char vexname;
	ArcNode *firstarc;
	int OutDegree;
	int InDegree;
}VexNode,VList[MAX_VERTEX_NUM];

//ͼ
typedef struct
{
	VList vexs;
	int vexnum,arcnum;
}AlGraph;

//����
typedef struct QNode
{
	ElemType data;
	QNode *next;
}QNode,*QueuePtr;

typedef struct
{
	QueuePtr front;
	QueuePtr rear;
}LinkQueue;

Status InitQueue(LinkQueue &Q)
{
	if(!Q.front && !Q.rear)
	{
		Q.front = Q.rear = (QNode *)malloc(sizeof(QNode));
		Q.front->next = NULL;
		Q.rear->next = NULL;
	}
	return 1;
}

Status EnQueue(LinkQueue &Q,ElemType e)
{
	if(!Q.front && !Q.rear)
		return 0;
	QNode *p;
	p = (QNode *)malloc(sizeof(QNode));
	p->data = e;
	p->next = NULL;//*****************
	Q.rear->next = p;
	Q.rear = p;
	return 1;
}

Status DeQueue(LinkQueue &Q,ElemType &e)
{
	if(!Q.front && !Q.rear && Q.front == Q.rear)
		return 0;
	QNode *p;
	p = Q.front->next;
	Q.front->next = p->next;
	e = p->data;
	if(Q.rear == p)
		Q.rear = Q.front;
	free(p);
	return 1;
}

Status QueueEmpty(LinkQueue Q)
{
	if(!Q.front && !Q.rear)
		return 0;
	if(Q.front == Q.rear)
		return 1;
	return 0;
}

Status LocateVex(AlGraph G,char v)
{
	int i;
	for(i=0;i<G.vexnum;i++)
	{
		if(G.vexs[i].vexname == v)
			break;
	}
	return i;
}


//ͼ
Status CreatGraph(AlGraph &G)
{
	int i,m,n;
	char v1,v2;
	printf(">>>Input the number of vexnum:");
	scanf("%d",&G.vexnum);
	printf(">>>Input the number of arcnum:");
	scanf("%d",&G.arcnum);
	getchar();
	for(i=0;i<G.vexnum;i++)
	{
		printf(">>>Input the No.%d vexnum:",i+1);
		scanf("%c",&G.vexs[i].vexname);
		getchar();
		G.vexs[i].firstarc = NULL;
		G.vexs[i].OutDegree = 0;
		G.vexs[i].InDegree = 0;
	}
	for(i=0;i<G.arcnum;i++)
	{
		printf(">>>Input v&u(v->u):");
		scanf("%c->%c",&v1,&v2);
		getchar();
		m = LocateVex(G,v1);
		n = LocateVex(G,v2);
		ArcNode *p = (ArcNode *)malloc(sizeof(ArcNode));
		p->pos = n;
		p->arcdata = v2;
		p->next = G.vexs[m].firstarc;//*******ͷ�巨��������˳���й�
		G.vexs[m].firstarc = p;//**********
		G.vexs[m].OutDegree++;
		G.vexs[n].InDegree++;
	}
	printf(">>>Degree as follows:\n");
	printf("Vexs\tOutDegree\tInDegree\n");
	for(i=0;i<G.vexnum;i++)
	{
		printf("%3c\t%3d\t\t%3d\n",G.vexs[i].vexname,G.vexs[i].OutDegree,G.vexs[i].InDegree);
	}
	return 1;
}

Status BFSTraverse(AlGraph G)
{
	int i,k;
	ArcNode *p;
	LinkQueue Q;
	Q.front = NULL;
	Q.rear = NULL;
	InitQueue(Q);
	bool visit[MAX_VERTEX_NUM];
	for(i=0;i<G.vexnum;i++)
	{
		visit[i] = false;
	}
	for(k=0;k<G.vexnum;k++)
	{
		if(!visit[k])
		{
			EnQueue(Q,k);
			visit[i] = true;
			while(!QueueEmpty(Q))
			{
				DeQueue(Q,i);
				printf("%4c",G.vexs[i].vexname);
				p = G.vexs[i].firstarc;
				while(p)
				{
					if(!visit[p->pos])
					{
						EnQueue(Q,p->pos);
						visit[p->pos] = true;
					}
					p = p->next;
				}
			}

		}
	}
	printf("\n");
	return 1;
}

void main()
{
	int i;
	AlGraph G;
	printf(">>>GreatGraph:\n");
	CreatGraph(G);
	printf(">>>The AdjList as follows:\n");
	for(i=0;i<G.vexnum;i++)
	{
		printf("%4c",G.vexs[i].vexname);
		ArcNode *p = G.vexs[i].firstarc;
		while(p)
		{
			printf("%4c",p->arcdata);
			p = p->next;
		}
		printf("\n");
	}
	printf("BFSTraverse\n");
	BFSTraverse(G);
}
