#include<stdio.h>
#include<stdlib.h>
#define MAX_VERTEX_NUM 20
#define Status int
typedef int ElemType;

typedef struct ArcNode
{
	int pos;
	char vex;
	ArcNode *next;
}ArcNode;

typedef struct 
{
	char vexname;
	ArcNode *firstarc;
	int Indegree;
	int Outdegree;
}VNode,VList[MAX_VERTEX_NUM];

typedef struct
{
	VList vexs;
	int vexnum,arcnum;
}AlGraph;

//����
typedef struct QNode
{
	ElemType data;
	QNode *next;
}QNode,*Queueptr;

typedef struct
{
	Queueptr front;
	Queueptr rear;
}LinkQueue;

Status InitQueue(LinkQueue &Q)
{
	if(!Q.front && !Q.rear)
	{
		Q.front = Q.rear = (QNode *)malloc(sizeof(QNode));
		Q.front->next = NULL;
		Q.rear->next = NULL;
	}
	return 1;
}

Status EnQueue(LinkQueue &Q,ElemType e)
{
	if(!Q.front && !Q.rear)
		return 0;
	QNode *p;
	p = (QNode *)malloc(sizeof(QNode));
	p->data = e;
	p->next =NULL;
	Q.rear->next = p;
	Q.rear = p;
	return 1;
}

Status DeQueue(LinkQueue &Q,ElemType &e)
{
	if(!Q.front && !Q.rear)
		return 0;
	QNode *p;
	p = Q.front->next;
	e = p->data;
	Q.front->next = p->next;
	if(Q.rear == p)
		Q.rear = Q.front;
	free(p);
	return 1;
}

Status QueueEmpty(LinkQueue Q)
{
	if(!Q.front && !Q.rear)
		return 0;
	if(Q.front == Q.rear)
		return 1;
	return 0;
}

Status LocateVex(AlGraph G,char v)
{
	int i;
	for(i=0;i<G.vexnum;i++)
	{
		if(G.vexs[i].vexname == v)
			break;
	}
	return i;
}


//����ͼ
Status CreatGraph(AlGraph &G)
{
	ArcNode *p;
	int i,m,n;
	char v1,v2;
	printf(">>>Input the number of vexnum:");
	scanf("%d",&G.vexnum);
	printf(">>>Input the number of arcnum:");
	scanf("%d",&G.arcnum);
	getchar();
	//��ʼ��ͷ���
	for(i=0;i<G.vexnum;i++)
	{
		printf(">>>Input No.%d vex:",i+1);
		scanf("%c",&G.vexs[i].vexname);
		getchar();
		G.vexs[i].firstarc = NULL;
		G.vexs[i].Indegree = 0;
		G.vexs[i].Outdegree = 0;
	}
	for(i=0;i<G.arcnum;i++)
	{
		printf(">>>Input v&u(v->u):");
		scanf("%c->%c",&v1,&v2);
		getchar();
		m = LocateVex(G,v1);
		n = LocateVex(G,v2);
		p = (ArcNode *)malloc(sizeof(ArcNode));
		p->next = NULL;
		p->vex = v2;
		p->pos = n;
		p->next = G.vexs[m].firstarc;
		G.vexs[m].firstarc = p;
		G.vexs[m].Outdegree++;
		G.vexs[n].Indegree++;
	}
	printf(">>>Degree as follow:\n");
	printf("Vex\tOutdegree\tIndegree\n");
	for(i=0;i<G.vexnum;i++)
	{
		printf("%2c\t%4d\t\t%4d\n",G.vexs[i].vexname,G.vexs[i].Outdegree,G.vexs[i].Indegree);
	}
	return 1;
}

//��������
Status Topological(AlGraph G)
{
	int i;
	int count = 0;
	ArcNode *p;
	LinkQueue Q;
	Q.front = Q.rear = NULL;
	InitQueue(Q);
	for(i=0;i<G.vexnum;i++)
	{
		if(!G.vexs[i].Indegree)
			EnQueue(Q,i);
	}
	while(!QueueEmpty(Q))
	{
		DeQueue(Q,i);
		printf("%4c",G.vexs[i].vexname);
		count++;
		p = G.vexs[i].firstarc;
		while(p)
		{
			if(!(--G.vexs[p->pos].Indegree))
				EnQueue(Q,p->pos);
			p = p->next;
		}
	}
	printf("\n");
	if(count < G.vexnum)
		printf(">>>There is a circle!\n");
	return 1;
}

void main()
{
	int i;
	ArcNode *p;
	AlGraph G;
	printf(">>>CreatGraph\n");
	CreatGraph(G);
	printf(">>>AdjList as follows:\n");
	for(i=0;i<G.vexnum;i++)
	{
		printf("%3c",G.vexs[i].vexname);
		p = G.vexs[i].firstarc;
		while(p)
		{
			printf("%3c",p->vex);
			p = p->next;
		}
		printf("\n");
	}
	printf(">>>Topological:\n");
	Topological(G);
	printf("OVER!");
}
