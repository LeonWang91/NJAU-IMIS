#include<stdio.h>
#define MAX_VERTEX_NUM 20  //��󶥵����
#define INFINITY 666


typedef struct Arecell
{
	int adj;		//�����ϵ���ͣ�������Ȩͼ����1��0��ʾ�������;
}AreCell,AdjMatrix[MAX_VERTEX_NUM][MAX_VERTEX_NUM];

typedef struct
{
	char vexs[MAX_VERTEX_NUM];        //��Ŷ��������
	AdjMatrix arcs;                   //���adj���ڽӾ��󣬶�ά����
	int vexnum,arcnum;                //ͼ�ĵ�ǰ�������ͻ���
}MGraph;

int LocateVex(MGraph &G,char vex)
{
	int m;
	for(m=0;m<G.vexnum;m++)
	{
		if(G.vexs[m]==vex)
			break;
	}
	return m;
}


//����ͼ���������
void CreatGraph(MGraph &G,char *vexs,AdjMatrix arcs)
{
	int i,j;
	int sum1=0,sum2=0;
	printf(">>>Input vexnum:");
	scanf("%d",&G.vexnum);
	printf(">>>Input arcnum:");
	scanf("%d",&G.arcnum);
	getchar();
	printf(">>>Input vexs:");
	for(i=0;i<G.vexnum;i++)   //���춥������
	{
		scanf("%c",&G.vexs[i]);
		getchar();
		if(i<G.vexnum-1)
			printf(">>>Continue input:");
	}
	printf("\n");
	for(i=0;i<G.vexnum;i++)   //��ʼ���ڽӾ���
	{
		for(j=0;j<G.vexnum;j++)
		{
			G.arcs[i][j].adj= INFINITY;
		}
	}

	for(int m=0;m<G.arcnum;m++)
	{
		char v1,v2;
		int weight;
		printf(">>>Input one of adjvexs:");
		scanf("%c",&v1);
		getchar();
		printf(">>>Input another adjvex:");
		scanf("%c",&v2);
		getchar();
		i = LocateVex(G,v1);
		j = LocateVex(G,v2);
		printf("Input the weight:");
		scanf("%d",&weight);
		getchar();
		G.arcs[i][j].adj = weight;
		printf("\n");

	}

	for(i=0;i<G.vexnum;i++)
	{
		for(j=0;j<G.vexnum;j++)
		{
			if(G.arcs[i][j].adj != INFINITY)
				sum1++;
		}
		printf("%c out_degree is %d.\t",G.vexs[i],sum1);
		sum1=0;
	}
	printf("\n");
	for(j=0;j<G.vexnum;j++)
	{
		for(i=0;i<G.vexnum;i++)
		{
			if(G.arcs[i][j].adj != INFINITY)
				sum2++;
		}
		printf("%c in_degree is %d.\t",G.vexs[j],sum2);
		sum2=0;
	}
	printf("\n\n");
	printf("Over!\n");
}

//���·��
void ShortestPath_DIJ(MGraph G,int v0,int *D,int (*Path)[MAX_VERTEX_NUM])
{
	int v,w;
	int length=0;
	bool final[MAX_VERTEX_NUM];
	for(v=0;v<G.vexnum;v++)
	{
		final[v]=false;
		D[v]=G.arcs[v0][v].adj;
		for(w=0;w<G.vexnum;w++)
		{
			Path[v][w]=0;
		}
		if(D[v]<INFINITY)
		{
			Path[v][v0]=1;//��V0����
		}
	}
	D[v0]=0;
	final[v0]=true;//��ʼ����v0��������s��
	for(int m=1;m<G.vexnum;m++)
	{
		int min=INFINITY;
		for(w=0;w<G.vexnum;w++)
		{
			if(!final[w])
			{
				if(D[w]<min)
				{
					v=w;
					min=D[w];
				}
			}
		}
		final[v]=true;
		Path[v][++length]=v;
		for(w=0;w<G.vexnum;w++)
		{
			if(!final[w]&&((min+G.arcs[v][w].adj)<D[w]))
			{
				D[w]=min+G.arcs[v][w].adj;
				for(int i=1;i<=length;i++)
				{
					Path[w][i]=Path[v][i];
				}
				Path[w][0]++;
				Path[w][++length]=w;
			}
		}
	}
}

void main()
{
	int i,j;
	MGraph G;
	int V0,V;
	int D[MAX_VERTEX_NUM];//��¼��V0�����������Сֵ
	int Path[MAX_VERTEX_NUM][MAX_VERTEX_NUM];//��¼·��
	printf(">>>Creating...\n");
	CreatGraph(G,G.vexs,G.arcs);
	for(i=0;i<G.vexnum;i++)
	{
		for(j=0;j<G.vexnum;j++)
		{
			printf("%5d",G.arcs[i][j].adj);
		}
		printf("\n");
	}
	printf("\nAdjMatrix Created!\n");
	printf("Input the start V0(int):");
	scanf("%d",&V0);
	ShortestPath_DIJ(G,V0,D,Path);
	printf("ShortestPath_DIJ\t\tPathLength\n");
	for(i=0,V=0;i<G.vexnum;i++)
	{	
		printf("<%c,%c>\t\t\t\t%d\n",G.vexs[V0],G.vexs[V],D[V]);
		V++;
	}
	printf("\n>>>PathArray\n");
	for(i=0;i<G.vexnum;i++)
	{
		printf("V0->V%d\t",i);
		for(j=0;j<G.vexnum;j++)
		{
			printf("%5d",Path[i][j]);
		}
		printf("\n");
	}
	printf("\n>>>Over!\n");
}






