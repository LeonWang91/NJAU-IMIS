#include<stdio.h>
#include<stdlib.h>
#define Status int
#define MAX_VERTEX_NUM 20
typedef int ElemType;

//�����
typedef struct ArcNode
{
	int pos;
	char vex;
	int weight;
	ArcNode *next;
}ArcNode;

//ͷ���
typedef struct
{
	char vexname;
	ArcNode *firstarc;
	int Indegree;
	int Outdegree;
}VNode,VList[MAX_VERTEX_NUM];

//ͼ
typedef struct
{
	VList vexs;
	int vexnum,arcnum;
}AlGraph;

//ջ
typedef struct SNode
{
	ElemType data;
	SNode *next;
}SNode,*LinkStack;

Status InitStack(LinkStack &S)
{
	if(!S)
	{
		S = (SNode *)malloc(sizeof(SNode));
		S->next = NULL;
	}
	return 1;
}

Status Push(LinkStack &S,ElemType e)
{
	if(!S)
		return 0;
	SNode *p,*q;
	p = S;
	q = (SNode *)malloc(sizeof(SNode));
	q->data = e;
	q->next = NULL;
	q->next = p->next;
	p->next = q;
	return 1;
}

Status Pop(LinkStack &S,ElemType &e)
{
	if(!S && !S->next)
		return 0;
	SNode *p,*q;
	p = S;
	q = p->next;
	e = q->data;
	p->next = q->next;
	return 1;
}

Status StackEmpty(LinkStack S)
{
	if(!S)
		return 0;
	if(!S->next)
		return 1;
	return 0;
}

Status LocateVex(AlGraph G,char v)
{
	int i;
	for(i=0;i<G.vexnum;i++)
	{
		if(G.vexs[i].vexname == v)
			break;
	}
	return i;
}

//����ͼ
Status CreatGraph(AlGraph &G)
{
	ArcNode *p,*q;
	int i,m,n;
	char v1,v2;
	printf(">>>Input the number of vexnum:");
	scanf("%d",&G.vexnum);
	printf(">>>Input the number of arcnum:");
	scanf("%d",&G.arcnum);
	getchar();
	//��ʼ��ͷ���
	for(i=0;i<G.vexnum;i++)
	{
		printf(">>>Input No.%d vex:",i+1);
		scanf("%c",&G.vexs[i].vexname);
		getchar();
		G.vexs[i].firstarc = NULL;
		G.vexs[i].Indegree = 0;
		G.vexs[i].Outdegree = 0;
	}
	for(i=0;i<G.arcnum;i++)
	{
		printf(">>>Input v&u(v->u):");
		scanf("%c->%c",&v1,&v2);
		m = LocateVex(G,v1);
		n = LocateVex(G,v2);
		p = (ArcNode *)malloc(sizeof(ArcNode));
		p->next = NULL;
		printf(">>>Input between weight:");
		scanf("%d",&p->weight);
		getchar();
		p->vex = v2;
		p->pos = n;
		p->next = G.vexs[m].firstarc;
		G.vexs[m].firstarc = p;
		G.vexs[m].Outdegree++;
		G.vexs[n].Indegree++;
	}
	printf(">>>Degree as follow:\n");
	printf("Vex\tOutdegree\tIndegree\n");
	for(i=0;i<G.vexnum;i++)
	{
		printf("%2c\t%4d\t\t%4d\n",G.vexs[i].vexname,G.vexs[i].Outdegree,G.vexs[i].Indegree);
	}
	printf(">>>Weight as follow:\n");
	printf("Vexs\tWeight\n");
	for(i=0;i<G.vexnum;i++)
	{
		q = G.vexs[i].firstarc;
		while(q)
		{
			printf("<%c,%c>\t%4d\n",G.vexs[i].vexname,G.vexs[q->pos].vexname,q->weight);
			q = q->next;
		}
	}
	return 1;
}

//�ؼ�·��
Status CriticalPath(AlGraph G,LinkStack T,int *ve)
{
	int i,j,k;
	int ee,el;
	ArcNode *p,*q;
	int vl[MAX_VERTEX_NUM];
	for(i=0;i<G.vexnum;i++)
	{
		vl[i] = ve[G.vexnum-1]; //���һ������ٷ���ʱ��϶�Ϊ���ֵ��Ϊ�ؼ�·�� ve = vl;
	}
	while(!StackEmpty(T))
	{
		Pop(T,k);
		p = G.vexs[k].firstarc;
		while(p)
		{
			if(vl[p->pos] - p->weight < vl[k])//(vl[p->pos] - p->weight)min  Ŀ���Ǹ���vl[k]
				vl[k] = vl[p->pos] - p->weight;
			p = p->next;
		}
	}
	for(j=0;j<G.vexnum;j++)//����ͼÿ��ͷ����ÿ������Ҫ��
	{
		q = G.vexs[j].firstarc;
		while(q)
		{
			ee = ve[j];
			el = vl[q->pos] - q->weight;
			if(ee == el)
				printf("<%c,%c>\n",G.vexs[j].vexname,G.vexs[q->pos].vexname);
			q = q->next;
		}
	}
	return 1;
}


//��������
Status TopologicalSort(AlGraph G)
{
	int i,k;
	int count=0;
	int ve[MAX_VERTEX_NUM];
	ArcNode *p;
	LinkStack S,T;
	S = NULL;
	T = NULL;
	InitStack(S);
	InitStack(T);
	for(i=0;i<G.vexnum;i++)
	{
		ve[i] = 0; //��һ�������緢��ʱ��϶�Ϊ0��Ϊ�ؼ�·�� ve = vl;
		if(!G.vexs[i].Indegree)
			Push(S,i);
	}
	while(!StackEmpty(S))
	{
		Pop(S,k);
		Push(T,k);
		printf("%3c",G.vexs[k].vexname);
		count++; 
		p = G.vexs[k].firstarc;
		while(p)
		{
			if(!(--G.vexs[p->pos].Indegree))
				Push(S,p->pos);
			if(ve[k] + p->weight > ve[p->pos])  //(ve[k] + p->weight)max 
				ve[p->pos] = ve[k] + p->weight;
			p = p->next;
		}
	}
	printf("\n");
	if(count < G.vexnum)
		printf(">>>There is a circle!\n");
	printf(">>>CriticalPath\n");
	CriticalPath(G,T,ve);
	return 1;
}

void main()
{
	int i;
	ArcNode *p;
	AlGraph G;
	printf(">>>GreatGraph\n");
	CreatGraph(G);
	printf(">>>AdjList as follows:\n");
	for(i=0;i<G.vexnum;i++)
	{
		printf("%3c",G.vexs[i].vexname);
		p = G.vexs[i].firstarc;
		while(p)
		{
			printf("%3c",p->vex);
			p = p->next;
		}
		printf("\n");
	}
	printf(">>>TopologicalSort\n");
	TopologicalSort(G);
	printf("OVER!\n");
}