﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    class Program
    {
        public delegate void mydelegate(int n);
        public delegate void mydelegate1(double x, double y);
        class MyDeclass
        {
            public void fun1(int n)
            {
                Console.WriteLine("{0}的2倍={1}", n, 2 * n);
            }
            public void fun2(int n)
            {
                Console.WriteLine("{0}的3倍={1}", n, 3 * n);
            }
        }
        class MyDeclass1
        {
            public void add(double x,double y)
            {
                Console.WriteLine("{0}+{1}={2}", x, y, x + y);
            }
            public void sub(double x, double y)
            {
                Console.WriteLine("{0}-{1}={2}", x, y, x - y);
            }
            public void mul(double x, double y)
            {
                Console.WriteLine("{0}*{1}={2}", x, y, x * y);
            }
            public void div(double x, double y)
            {
                Console.WriteLine("{0}/{1}={2}", x, y, x / y);
            }
        }
        static void Main(string[] args)
        {
            MyDeclass obj = new MyDeclass();
            mydelegate p = new mydelegate(obj.fun1);
            p(5);
            p = new mydelegate(obj.fun2);
            p(3);
            MyDeclass1 obj1 = new MyDeclass1();
            mydelegate1 p1,a;
            a = obj1.add;
            p1 = a;
            a = obj1.sub;
            p1 += a;
            a = obj1.mul;
            p1 += a;
            a = obj1.div;
            p1 += a;
            p1(5, 8);


        }
    }
}
