﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract
{
    class Program
    {
        abstract class A
        {
            protected int x = 2;
            protected int y = 3;
            public abstract void fun();
            public abstract int px { get; set; }
            public abstract int py { get; }
        }
        class B:A
        {
            public override void fun()
            {
                x++;y++;
            }
            public  override int px
            {
                get { return x + 10; }
                set { x = value; }
            }
            public override int py
            {
                get { return y + 10; }
            }
        }
        static void Main(string[] args)
        {
            B b = new B();
            b.px = 5;
            b.fun();
            Console.WriteLine("x={0},y={1}", b.px, b.py);
        }
    }
}
