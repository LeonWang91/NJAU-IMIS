﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism
{
    class Program
    {
        class A
        {
            public void fun()
            {
                Console.WriteLine("A");
            }
            public static int val = 123;
        }
        class B:A
        {
            new public void fun()
            {
                Console.WriteLine("B");
            }
            new public static int val = 456;
        }
        static void Main(string[] args)
        {
            B b = new B();
            b.fun();
            Console.WriteLine(B.val);
        }
    }
}
