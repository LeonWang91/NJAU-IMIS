﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Caculater
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox3.Enabled = false;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButton1.Checked)
            {
                label.Text = "+";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                label.Text = "-";
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
            {
                label.Text = "*";
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
            {
                label.Text = "/";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a, b, c;

            a = Convert.ToInt32(textBox1.Text);
            b = Convert.ToInt32(textBox2.Text);
            if(label.Text == "+")
            {
                c = a + b;
                textBox3.Enabled = true;
                textBox3.Text = Convert.ToString(c);
            }
            if (label.Text == "-")
            {
                c = a - b;
                textBox3.Enabled = true;
                textBox3.Text = Convert.ToString(c);
            }
            if (label.Text == "*")
            {
                c = a * b;
                textBox3.Enabled = true;
                textBox3.Text = Convert.ToString(c);
            }
            if (label.Text == "/")
            {
                if (b == 0)
                {
                    MessageBox.Show("输入的值不能为0，请重新输入！", "错误提示", MessageBoxButtons.OK);
                }
                else
                {
                    c = a / b;
                    textBox3.Enabled = true;
                    textBox3.Text = Convert.ToString(c);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox3.Enabled = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int n = 0;
                n = int.Parse(this.textBox1.Text.Trim());
            }
            catch
            {
                MessageBox.Show("请输入数字", "错误提示", MessageBoxButtons.YesNo);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int n = 0;
                n = int.Parse(this.textBox1.Text.Trim());
            }
            catch
            {
                MessageBox.Show("请输入数字", "错误提示", MessageBoxButtons.YesNo);
            }
        }
    }
}
