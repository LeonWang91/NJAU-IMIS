﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface2
{
    public interface IPictManip
    {
        void Dellmage();
        void ShowImage();
    }
    public interface IPicture
    {
        void ApplyAlpha();
        void ShowImage();
    }
    public class MyPicture:IPictManip,IPicture
    {
        public void Dellmage()
        {
            Console.WriteLine("Dellmage 实现！");
        }
        public void ApplyAlpha()
        {
            Console.WriteLine("ApplyAlpha 实现！");
        }
        void IPictManip.ShowImage()
        {
            Console.WriteLine("ShowImage 的 iPicture 实现");
        }
        void IPicture.ShowImage()
        {
            Console.WriteLine("ShowImage 的 IPictManip 实现");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MyPicture objM = new MyPicture();
            IPicture Pict = objM;
            Pict.ShowImage();
            IPictManip IPict = objM;
            IPict.ShowImage();
        }
    }
}
