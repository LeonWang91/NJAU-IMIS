﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassEvent
{
    class Program
    {
        public class Teacher
        {
            private string tname;
            public delegate void delegateType();
            public event delegateType ClassEvent;
            public Teacher(string name)
            {
                this.tname = name;
            }
            public void Start()
            {
                Console.WriteLine(tname + "教师宣布开始上课：");
                if(ClassEvent != null)
                {
                    ClassEvent();
                }
            }
        }
        public class Student
        {
            private string sname;
            public Student(string name)
            {
                this.sname = name;
            }
            public void Listener()
            {
                Console.WriteLine("学生" + sname + "正在认真听课");
            }
            public void Record()
            {
                Console.WriteLine("学生" + sname + "正在做笔记");
            }
            public void Sleeping()
            {
                Console.WriteLine("学生" + sname + "正在睡觉或玩手机");
            }
        }
        static void Main(string[] args)
        {
            Teacher t = new Teacher("李明");
            Student s1 = new Student("许强");
            Student s2 = new Student("陈兵");
            Student s3 = new Student("张英");
            t.ClassEvent += new Teacher.delegateType(s1.Listener );
            t.ClassEvent += new Teacher.delegateType(s2.Record);
            t.ClassEvent += new Teacher.delegateType(s3.Sleeping);
            t.Start();
        }
    }
}
