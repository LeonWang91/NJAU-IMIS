﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceI
{
    public interface Ia
    {
        float getarea();
    }
    public class Rectangle:Ia
    {
        float x, y;
        public Rectangle(float x,float y)
        {
            this.x = x;
            this.y = y;
        }
        public float getarea()
        {
            return x * y;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle box1 = new Rectangle(2.5f, 3.0f);
            Console.WriteLine("长方形面积：{0}", box1.getarea());
        }
    }
}
