﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface3
{
    interface Ia
    {
        float getarea();
    }
    public class Rectangle : Ia
    {
        float x, y;
        public Rectangle(float x,float y)
        {
            this.x = x;
            this.y = y;
        }
        float Ia.getarea()
        {
            return x * y;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Rectangle box1 = new Rectangle(2.5f, 3.0f);
            Ia ia = (Ia)box1;   //????????????????????????????????????
            Console.WriteLine("长方形面积：{0}", ia.getarea());
        }
    }
}
