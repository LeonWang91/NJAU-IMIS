﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class Program
    {
        class A
        {
            private int x;
            public A()
            {
                Console.WriteLine("调用类A的构造函数");
            }
            public A(int x)
            {
                this.x = x;
                Console.WriteLine("调用类A的重载构造函数");
            }
        }
        class B:A
        {
            private int y;
            public B()
            {
                Console.WriteLine("调用类B的构造函数");
            }
            public B(int x,int y):base(x)
            {
                this.y = y;
                Console.WriteLine("调用类B的重载构造函数");
            }
        }
        class C : B
        {
            private int z;
            public C()
            {
                Console.WriteLine("调用类C的构造函数");
            }
            public C(int x,int y,int z):base(x,y)
            {
                this.z = z;
                Console.WriteLine("调用类C的重载构造函数");
            }
        }
        static void Main(string[] args)
        {
            C c = new C(1, 2, 3);
        }
    }
}
