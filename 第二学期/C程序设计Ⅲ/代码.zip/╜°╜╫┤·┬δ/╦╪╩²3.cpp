#include<stdio.h>
#include<math.h>
int main()
{
	int i,j,m;
	for(i=2;i<=100;i++)
	{
		for(j=2;j<=sqrt(i);j++)
		{
			m=i%j;
			if(m==0)
			break;
		}
		if(j<=sqrt(i))
			printf("%d is not a prime.\n",i);
		else
			printf("%d is a prime.\n",i);
	}
	printf("\n");
	return 0;
}