#include<stdio.h>
int main()
{
	int m,i;
	printf("��Щ����������:\n");
	for(m=2;m<=100;m++)
	{
		for(i=2;i<=m;i++)
		{
			if(m%i==0)
					break;
		}
		if(i==m)
			printf("%4d\n",m);
			/*if(m%i==0)
			{
				if(i<m)
					break;
				else
					printf("%6d",m);
			}
		}*/
	}
	return 0;
}