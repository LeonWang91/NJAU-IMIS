#include<stdio.h>
int main()
{
	double salary,tax,pay;
	printf("�����������µĹ���:\n");
	scanf("%lf",&salary);
	if(salary<=5000)
	{	
		tax=0;
		pay=0;
		printf("pay=%f",pay);
	}
	else if(salary<=8000)
	{	
		tax=0.03;
		pay=(salary-5000)*0.03;
		printf("pay=%f",pay);
	}
	else if(salary<=17000)
	{	
		tax=0.1;
		pay=(salary-5000)*0.1-(8000-5000)*(0.1-0.03);
		printf("pay=%f",pay);
	}
	else if(salary<=30000)
	{	
		tax=0.2;
 		pay=(salary-5000)*0.2-(17000-5000)*(0.2-0.1)-(8000-5000)*(0.1-0.03);
		printf("pay=%f",pay);
	}
	else if(salary<=40000)
	{	
		tax=0.25;
		pay=(salary-5000)*0.25-(30000-5000)*(0.25-0.2)-(17000-5000)*(0.2-0.1);
		printf("pay=%f",pay);
	}
	else if(salary<=60000)
	{
		tax=0.3;
		pay=(salary-5000)*0.3-(40000-5000)*(0.3-0.25)-(30000-5000)*(0.25-0.2);
		printf("pay=%f",pay);
	}
	else if(salary<=85000)
	{	
		tax=0.35;
		pay=(salary-5000)*0.35-(60000-5000)*(0.35-0.3)-(40000-5000)*(0.3-0.25);
		printf("pay=%f",pay);
	}
	else if(salary>85000)
	{	
		tax=0.45;
		pay=(salary-5000)*0.45-(85000-5000)*(0.45-0.35)-(60000-5000)*(0.35-0.3);
		printf("pay=%f",pay);
	}
	return 0;
}