#include<stdio.h>
int main()
{
	int a[10];
	int i;
	printf("Please enter 10 numbers:");
	for(i=0;i<10;i++)
		scanf("%d",&a[i]);
	for(i=0;i<10;i++)
		printf("%4d",a[i]);
	printf("\n");
	return 0;
}