#include<stdio.h>
int main()
{
	void swap(int *p1,int *p2);
	int a,b;
	int *p1,*p2;
	printf("Please input two numbers:\n");
	scanf("%d%d",&a,&b);
	p1=&a;
	p2=&b;
	if(a<b)
		swap(p1,p2);
	printf("a=%d,a=%d\n",a,b);
	printf("max=%d,min=%d\n",*p1,*p2);
	return 0;
}

void swap(int *p1,int *p2)
{
	int temp;
	temp=*p1;
	*p1=*p2;
	*p2=temp;
}