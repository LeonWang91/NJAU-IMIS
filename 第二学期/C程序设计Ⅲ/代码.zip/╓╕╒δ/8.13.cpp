#include<stdio.h>
int main()
{
	int a[3][4]={1,3,5,7,9,11,13,15,17,19,21,23};
	int (*p)[4];
	int i,j;
	p=a;
	printf("Please enter row and column:\n");
	scanf("%d%d",&i,&j);
	if(i>2 || j>3)
		printf("Error!\n");
	else
		printf("a[%d][%d]=%d\n",i,j,*(*(p+i)+j));
	return 0;
}