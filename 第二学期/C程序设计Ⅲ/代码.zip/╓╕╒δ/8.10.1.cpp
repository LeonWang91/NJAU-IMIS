#include<stdio.h>
int main()
{
	void sort(int x[],int n);
	int i,*p,a[10];
	p=a;
	printf("The orginal numbers:\n");
	for(i=0;i<10;i++)
		scanf("%d",p++);
	p=a;
	sort(a,10);
	printf("The sorted numbers:\n");
	for(i=0;i<10;i++,p++)
		printf("%4d",*p);
	printf("\n");
	return 0;
}


void sort(int x[],int n)
{
	int i,j,k,temp;
	for(i=0;i<(n-1);i++)
	{
		k=i;					//��ֵ���ע��˳��
		for(j=i+1;j<n;j++)
			if(x[j]>x[k])
				k=j;
		if(i!=k)
		{
			temp=x[i];
			x[i]=x[k];
			x[k]=temp;
		}
	}
}
