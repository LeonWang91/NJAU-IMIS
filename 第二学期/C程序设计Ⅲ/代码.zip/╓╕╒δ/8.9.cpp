//��ָ�������ʵ�κ��β�

#include<stdio.h>
int main()
{
	void inv(int *x,int n);
	int a[10],i,*p;
	p=a;
	printf("The original array:\n");
	for(i=0;i<10;i++,p++)
		scanf("%d",p);
	printf("\n");
	p=a;
	inv(p,10);
	printf("The sorted array:\n");
	for(i=0;i<10;i++,p++)
		printf("%4d",p);
	printf("\n");
	return 0;
}

void inv(int *x,int n)
{
	int *i,*j,*p;
	int m,temp;
	m=(n-1)/2;
	i=x;
	j=x+n-1;
	p=x+m;
	for(i=0;i<=p;i++,j--)
	{
		temp=*i;
		*i=*j;
		*j=temp;
	}
}