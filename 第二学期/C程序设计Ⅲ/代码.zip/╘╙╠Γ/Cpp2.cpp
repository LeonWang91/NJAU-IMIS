#include <stdio.h>
int main()
{ 
	float pi=3.1415927;
    printf("%f,%.4f,%4.3f,%10.3f",pi,pi,pi,pi);
    printf("\n%e,%.4e,%4.3e,%10.3e",pi,pi,pi,pi);
	return 0;
}