#include<stdio.h>
int main()
{
	void average(float *x,int n);
	void search(float(*y)[4],int m);
	float score[3][4]={{65,67,70,60},{80,87,90,81},{90,99,100,98}};
	average(*score,12);
	search(score,2);
	return 0;
}

void average(float *x,int n)
{
	float *i;
	float sum=0,aver;
	for(i=x;i<x+n;i++)
		sum+=(*i);
	aver=sum/n;
	printf("The average is %5.2f\n",aver);
}

void search(float(*y)[4],int m)
{
	int j;
	printf("The NO.%d student scores are:\n",m);
	for(j=0;j<4;j++)
		printf("%8.2f",*(*(y+m-1)+j));
	printf("\n");
}
		
