#include<stdio.h>
int main()
{
	float a=18.5;
	printf("%g",a);
	return 0;
}