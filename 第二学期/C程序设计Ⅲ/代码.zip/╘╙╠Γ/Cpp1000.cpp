#include<stdio.h>
int main()
{
	int i;
	char str[4]={'g','o','o','d'};
	printf("%s",str);
	return 0;
}