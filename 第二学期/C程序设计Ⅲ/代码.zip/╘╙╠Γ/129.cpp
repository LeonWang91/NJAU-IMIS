#include<stdio.h>
int main()
{
	int i;
	char s[10]={'S','e','t','\0','u','p','\0'};
	for(i=0;i<10;i++)
		printf("%c\n",s[i]);
	return 0;
}
