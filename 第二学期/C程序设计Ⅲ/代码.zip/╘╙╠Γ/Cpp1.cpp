#include<stdio.h>
void main()
{
	int g=5,h=3,k;
	k=sub(g,h);
	printf("%d\n",k);
}

sub(char x,char y)
{
	int z;
	z=x%y;
	return z;
}
