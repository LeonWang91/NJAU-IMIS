#include<stdio.h>
int main()
{
	void search(float(*p)[4],int n);
	float score[3][4]={{65,57,70,60},{58,87,90,81},{90,99,100,98}};
	search(score,3);
	return 0;
}


void search(float(*p)[4],int n)
{
	int flag,i,j;
	for(i=0;i<n;i++)
	{
		flag=0;
		for(j=0;j<4;j++)
			if(*(*(p+i)+j)<60)
				flag=1;
		if(flag)
		{
			printf("No.%d student fails his scores are:\n",n+1);
			for(j=0;j<4;j++)
			printf("%8.2f",*(*(p+i)+j));
		}
	}
}
			
			