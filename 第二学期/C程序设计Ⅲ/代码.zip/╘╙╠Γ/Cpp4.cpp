#include<stdio.h>
int main()
{
	char s1[5];
	scanf("%s",s1);
	printf("%10.3s",s1);
	return 0;
}