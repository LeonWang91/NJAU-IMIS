#include<stdio.h>
void main()
{
	int i;
	char j;
	for(i=0;i<2;i++)
		scanf(" %c",&j);
	printf("%d",j);
}
