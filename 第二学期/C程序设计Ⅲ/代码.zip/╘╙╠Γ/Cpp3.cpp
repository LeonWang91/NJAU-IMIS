#include<stdio.h>
void main()
{
	int i,j;
	for(i=0,j=1;i<=j+1;i+=2,j--)
		printf("%d\n",i);
}