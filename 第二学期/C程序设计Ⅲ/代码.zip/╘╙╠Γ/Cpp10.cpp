#include<stdio.h>
int main()
{
	int i;
	char s[]="Helloboy";
	s[5]=32;
	s[6]=0;
	for(i=0;i<9;i++)
		printf("%c",s[i]);
	return 0;
}