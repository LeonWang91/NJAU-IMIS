#include<stdio.h>
#include<string.h>
int main()
{
	int i,j;
	int upp,low,dig,spa,oth;
	char text[3][80];
	upp=low=dig=spa=oth=0;						//�����õ��Ӽ�����ı�������Ҫ����ʼֵΪ0
	for(i=0;i<3;i++)
	{	
		printf("Please input line %d\n",i+1);
		gets(text[i]);
		for(j=0;j<80&&text[i][j]!='\0';j++)
		{
			if(text[i][j]>='A'&&text[i][j]<='Z')
				upp++;
			else if(text[i][j]>='a'&&text[i][j]<='z')
				low++;
			else if(text[i][j]>='0'&&text[i][j]<='9')
				dig++;
			else if(text[i][j]==' ')				//һ����'>='/'<='/'=='�������Ӧ
				spa++;
			else
				oth++;
		}
	}
	printf("uppers:%d\n",upp);
	printf("lowers:%d\n",low);
	printf("digits:%d\n",dig);
	printf("spaces:%d\n",spa);
	printf("others:%d\n",oth);
	return 0;
}
		

	
	