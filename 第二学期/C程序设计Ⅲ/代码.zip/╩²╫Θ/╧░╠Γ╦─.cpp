//�Ӵ�С����

#include<stdio.h>
int main()
{
	int i,j,k,t;
	int m;
	int a[11];
	printf("Please enter 10 numbers:\n");
	for(i=0;i<10;i++)
		scanf("%d",&a[i]);
	printf("The former array:\n");
	for(i=0;i<10;i++)
		printf("%4d",a[i]);
	printf("\n");
	for(i=0;i<9;i++)
	{
		k=i;
		for(j=i+1;j<10;j++)
			if(a[k]<a[j])
				k=j;
		if(i!=k)
		{
			t=a[i];
			a[i]=a[k];
			a[k]=t;
		}
	}
	printf("The sorted array:\n");
	for(i=0;i<10;i++)
		printf("%4d",a[i]);
	printf("\n");
	printf("Please insert a single number:\n");
	scanf("%d",&m);
	if(m<a[9])
		a[10]=m;
	else
		for(i=9;i>=0;i--)
			if(m>a[i])
			{
				a[i+1]=a[i];
				a[i]=m;
			}
	printf("The inserted array:\n");
	for(i=0;i<11;i++)
		printf("%4d",a[i]);
	printf("\n");
	return 0;
}




