#include<stdio.h>
#include<math.h>
int main()
{
	int i,j,m,n;
	int a[100];
	printf("���100���ڵ�����:\n");
	for(i=2;i<=100;i++)
	{
		a[i]=i;
		n=sqrt(a[i]);
		for(j=2;j<=n;j++)
			if(a[i]%j==0)
				break;
		if(j>n)
			printf("%4d",a[i]);
	}
	printf("\n");
	return 0;
}


