#include<stdio.h>
int main()
{
	int i,j,t;
	int a[10];
	printf("Please enter an array:\n");
	for(i=0;i<10;i++)
		scanf("%d",&a[i]);
	printf("The former array:\n");
	for(i=0;i<10;i++)
		printf("%4d",a[i]);
	printf("\n");
	for(j=0;j<5;j++)
	{
		t=a[j];
		a[j]=a[10-j-1];
		a[10-j-1]=a[i];
	}
	printf("The sorted array:\n");
	for(i=0;i<10;i++)
		printf("%4d",a[i]);
	printf("\n");
	return 0;
}
	

