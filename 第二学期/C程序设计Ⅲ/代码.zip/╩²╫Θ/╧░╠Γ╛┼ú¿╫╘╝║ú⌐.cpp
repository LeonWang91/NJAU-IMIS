#include<stdio.h>
int main()
#define N 5
{
	int begin,end,mid,sign,flag,loca;
	int a[N],i,number;
	char c;
	printf("Enter data:\n");
	scanf("%d",&a[0]);
	i=1;
	while(i<N)
	{
		scanf("%d",&a[i]);
		if(a[i]<=a[i-1])
			i++;
		else
			printf("Please enter this data again:\n");
	}
	printf("\n");
	for(i=0;i<5;i++)
		printf("%4d",a[i]);
	printf("\n");
	flag=1;
	while(flag)
	{
		printf("Input number to look for:\n");
		scanf("%d",&number);										//����ǰ��Ҫ��������������Ҫ�����ַ�ʱ
		getchar();													//************************���scanf�����Ļس��������Ե���****************************
		sign=0;
		begin=0;
		end=N-1;
		if((number>a[0])||(number<a[N-1]))
			loca=-1;
		while((!sign)&&(begin<=end))
		{
			mid=(begin+end)/2;
			if(number==a[mid])
			{
				loca=mid;
				printf("Has found %d,its position is :%d\n",number,loca+1);
				sign=1;
			}
			else if(number<a[mid])
				begin=mid+1;
			else
				end=mid-1;
		}
		if((!sign)||loca==-1)
			printf("Can not found %d.\n",number);
		/*char a=getchar();
		if(a=='\n')
		{
			printf("a=\\n\n",a);
		}
		*/
		printf("Continue or not<Y/N>:");
		scanf("%c",&c);
		if(c=='N'||c=='n')
			flag=0;
		printf("\n");
	}
		return 0;
}

			
			


