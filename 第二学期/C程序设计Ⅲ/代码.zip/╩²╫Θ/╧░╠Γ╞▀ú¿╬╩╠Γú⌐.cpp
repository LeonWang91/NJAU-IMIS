#include<>
int main()
{
	int i=0,j=0;
	int a,b,c;
	int a[3][3];
	a=a[i][j]+a[i][j+1]+a[i][j+2];
	b=a[i][j]+a[i+1][j]+a[i+2][j];
	c=a[i][i]+a[i+1][i+1]+a[i+2][i+2];
	if(a==b&&b==c)
		for(i=0;i<3;i++)
		{
			for(j=0;j<3;j++)
				printf("%4d",a[i][j]);
			printf("\n");
		}
	printf("\n");
	return 0;
}
			

