#include<stdio.h>
int main()
{
	int a[3][3]={{1,2,3},{4,5,6},{7,8,9}};
	int sum1,sum2;
	sum1=a[0][0]+a[1][1]+a[2][2];
	sum2=a[0][2]+a[1][1]+a[2][0];
	printf("%4d\n",sum1);
	printf("%4d\n",sum2);
	return 0;
}
