//����ʮ�����Ҳ�����China England America Spain Ireland Italy Swede India Canada Germany


#include<stdio.h>
#include<string.h>
int main()
{
	int i,j;
	char str[10][20],string[20];
	printf("Please enter the names of ten countries:\n");
	for(i=0;i<10;i++);
		gets(str[i]);
	printf("\n");
	for(j=0;j<9;j++)
	{
		for(i=0;i<9-j;i++)
		{
			if(strcmp(str[i],str[i+1])>0)
			{
				strcpy(string,str[i]);
				strcpy(str[i],str[i+1]);
				strcpy(str[i+1],string);
			}
		}
	}
	printf("The sorted countries are:\n");
	for(i=0;i<10;i++)
		puts(str[i]);
	return 0;
}


