#include<stdio.h>
int main()
{
	int a[3][3];
	int i,j,sum=0;
	printf("enter numbers:\n");
	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
			scanf("%4d",&a[i][j]);
	for(i=0;i<3;i++)
		sum=sum+a[i][i];
	printf("%4d\n",sum);
	return 0;
}