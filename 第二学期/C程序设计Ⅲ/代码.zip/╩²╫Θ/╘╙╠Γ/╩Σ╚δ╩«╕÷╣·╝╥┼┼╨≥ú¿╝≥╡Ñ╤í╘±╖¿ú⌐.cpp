//����ʮ�����Ҳ�����China England America Spain Ireland Italy Swede India Canada Germany


#include<stdio.h>
#include<string.h>
int main()
{
	int i,j,k;
	char str[10][20],string[20];
	printf("Please enter the names of ten countries:\n");
	for(i=0;i<10;i++);
		gets(str[i]);
	for(i=0;i<9;i++)
		k=i;
		for(j=i+1;j<=9;j++)
		{
			if(strcmp(str[j],str[k])<0)
				j=k;
				if(i!=k)
				{
					strcpy(string,str[i]);
					strcpy(str[i],str[k]);
					strcpy(str[k],string);	
				}
		}
	printf("The sorted countries are:\n");
	for(i=0;i<10;i++)
		printf("%10s",str);
	return 0;
}


