#include<stdio.h>
int main()
{
	int a[11],i,j,k,temp;
	int x,end,temp1,temp2;
	printf("Please input 10 numbers:\n");
	for(i=0;i<10;i++)
		scanf("%d",&a[i]);
	for(i=0;i<9;i++)
	{
		k=i;
		for(j=i+1;j<=9;j++)
		{
			if(a[j]<a[k])
				k=j;
		if(i!=k)
			{
				temp=a[i];
				a[i]=a[k];
				a[k]=temp;
			}
		}
	}
	printf("The sorted numbers:\n");
	for(i=0;i<10;i++)
		printf("%6d",a[i]);
	printf("\n");

	printf("Insert a number:");
	scanf("%d",&x);
	end=a[9];
	if(x>end)
		a[10]=x;
	else
	{
		for(i=0;i<10;i++)
		{
			if(a[i]>x)
			{
				temp1=a[i];
				a[i]=x;
				for(j=i+1;j<11;j++)
				{
					temp2=a[j];
					a[j]=temp1;
					temp1=temp2;
				}
				break;
			}
		}
	}
	printf("The sorted numbers:\n");
	for(i=0;i<11;i++)
		printf("%6d",a[i]);
	return 0;
}


			



