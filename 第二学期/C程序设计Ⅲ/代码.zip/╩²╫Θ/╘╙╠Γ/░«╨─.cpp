#include<stdio.h>
int main()
{
	char diamond[4][7]={{' ','*','*',' ','*','*'},{'*',' ',' ','*',' ',' ','*'},{' ',' ','*',' ','*'},{' ',' ',' ','*'}};
	int i,j;
	for(i=0;i<4;i++)
	{
		for(j=0;j<7;j++)
			printf("%c",diamond[i][j]);
		printf("\n");
	}
	return 0;
}