#include<stdio.h>
#include<string.h>
int main()
{
	int a[5]={8,6,5,4,1},temp1,temp2,i;
	temp1=a[4];
	temp2=a[3];
	a[4]=a[0];
	a[3]=a[1];
	a[0]=temp1;
	a[1]=temp2;
	for(i=0;i<5;i++)
		printf((i!=4)?"%4d":"%4d\n",a[i]);
	return 0;
}