#include<stdio.h>
int main()
{
	/*int a,b,c,i;
	i=a*b*c;
	for(i=1;i<=1000;i++)
	{
		if(i!=a+b+c)
			continue;
		else
			printf("%d its factors are %d,%d,%d",i,a,b,c);
	}
	return 0;*/
	int a,b,i;
	for(a=1;a<=1000;a++)
	{
		b=0;
		for(i=1;i<a;i++)
			if(a%i==0)
				b=b+i;     //b����ʾ��a�ĸ�������ӵĺ�
		if(b==a)
		{
			printf("%d,its factors are",a);
			for(i=1;i<a;i++)
				if(a%i==0)
					printf("%6d",i);
				printf("\n");
		}
	}
		
			
}