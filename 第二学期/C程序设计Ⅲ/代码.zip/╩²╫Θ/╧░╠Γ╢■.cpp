#include<stdio.h>
int main()
{
	int i,j,k,t;
	int a[10];
	printf("Please enter 10 numbers:\n");
	for(i=0;i<10;i++)
		scanf("%d",&a[i]);
	for(i=0;i<9;i++)
	{
		k=i;
		for(j=i+1;j<10;j++)
			if(a[k]<a[j])
				k=j;
		if(i!=k)
		{
			t=a[i];
			a[i]=a[k];
			a[k]=t;
		}
	}
	for(i=0;i<10;i++)
		printf("%4d",a[i]);
	printf("\n");
	return 0;
}


