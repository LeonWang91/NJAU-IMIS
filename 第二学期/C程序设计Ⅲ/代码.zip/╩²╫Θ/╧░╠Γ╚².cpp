#include<stdio.h>
int main()
{
	int i,j,sum=0;
	int a[3][3];
	printf("Please enter an array:\n");
	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
			scanf("%d",&a[i][j]);
	for(i=0;i<3;i++)
		sum+=a[i][i];
	printf("Sum=%d",sum);
	printf("\n");
	return 0;
}
