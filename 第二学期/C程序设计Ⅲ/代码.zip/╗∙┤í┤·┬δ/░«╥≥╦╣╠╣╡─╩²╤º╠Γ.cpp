#include<stdio.h>
int main()
{
	int number;
	for(number=14;;number++)
	{
		if(number%2==1&&number%3==2&&number%5==4&&number%6==5&&number%7==0)
		{
			printf("��ν��ݵĽ�������Ϊ:%d",number);
			break;
		}
	}
	return 0;
}