#include<stdio.h>
int main()
{
	int m,n,p,x,y,z;
	for(p=100;p<1000;p++)
	{
		x=p/100;
		y=p/10-x*10;
		z=p%10;
		m=100*x+10*y+z;
		n=x*x*x+y*y*y+z*z*z;
		if(m==n)
			printf("%d\n",n);
	}
	return 0;
}