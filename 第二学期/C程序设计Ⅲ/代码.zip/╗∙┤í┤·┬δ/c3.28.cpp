#include<stdio.h>
int main()
{
	int x,y;
	char ch;
	printf("\ninput two integers:");
	scanf("%d,%d",&x,&y);
	scanf("%ch",&ch);
	printf("x=%d,y=%d,ch=%c\n",x,y,ch);
	return 0;
}