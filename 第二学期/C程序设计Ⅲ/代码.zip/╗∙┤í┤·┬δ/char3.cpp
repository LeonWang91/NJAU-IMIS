#include<stdio.h>
int main()
{
	char c='?';
	printf("%d,%c\n",c,c);
	return 0;
}