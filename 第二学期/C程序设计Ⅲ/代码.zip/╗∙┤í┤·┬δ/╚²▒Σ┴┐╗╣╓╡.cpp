#include<stdio.h>
int main()
{
	double a,b,c,t;
	printf("������������ʵ��:\n");
	scanf("%lf%lf%lf",&a,&b,&c);
	if(a<b)
	{
		t=b;
		b=a;
		a=t;
	}
	if(a<c)
	{
		t=c;
		c=a;
		a=t;
	}
	if(b<c)
	{
		t=c;
		c=b;
		b=t;
	}
	printf("%f,%f,%f",a,b,c);
	return 0;
}