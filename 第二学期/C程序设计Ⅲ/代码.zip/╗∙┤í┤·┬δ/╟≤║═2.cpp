#include<stdio.h>
int main()
{
	int i=1,sum=0;
	do
	{
	 sum=sum+i;
	 i=i+1;
	}
	while(i<=100);
	printf("1~100���ܺ�Ϊ:%d\n",sum);
	return 0;
}