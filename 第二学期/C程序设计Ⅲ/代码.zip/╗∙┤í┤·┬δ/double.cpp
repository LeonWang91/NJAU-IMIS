#include<stdio.h>
int main()
{
	double a=12345678954321;
	printf("%f\t%e\t%g\n",a,a,a);
	return 0;
}