#include<stdio.h>
int main()
{
	char c1,c2,c3,c4,c5,c6,c7;
	c1=127;
	c2=128;
	c3=129;
	c4=130;
	c5=255;
	c6=256;
	c7=257;
	printf("%c %c %c %c %c %c %c\n",c1,c2,c3,c4,c5,c6,c7);
	printf("%d %d %d %d %d %d %d\n",c1,c2,c3,c4,c5,c6,c7);
	return 0;
}