#include<stdio.h>
int main()
{
	double salary,tax,pay;
	scanf("%lf",&salary);
	if(salary<=5000)
	{
		tax=0;
	    pay=0;
		printf("pay=%f",pay);
	}
	else
	{	if(salary<=8000)
		{	tax=0.03;
			pay=(12*salary-60000)*0.03;
			printf("pay=%f",pay);
		}
		else
		{	if(salary<=17000)
			{	tax=0.1;
				pay=36000*0.03+(12*salary-60000-36000)*0.1;
				printf("pay=%f",pay);
			}
			else
			{	if(salary<=30000)
				{	tax=0.2;
					pay=36000*0.03+(144000-36000)*0.1+(12*salary-60000-144000)*0.2;
					printf("pay=%f",pay);
				}
				else
				{	if(salary<=40000)
					{	tax=0.25;
						pay=36000*0.03+(144000-36000)*0.1+(300000-144000)*0.2+(12*salary-60000-300000)*0.25;
						printf("pay=%f",pay);
					}
					else
					{	if(salary<=60000)
						{	tax=0.3;
							pay=36000*0.03+(144000-36000)*0.1+(300000-144000)*0.2+(420000-300000)*0.25+(12*salary-60000-420000)*0.3;
							printf("pay=%f",pay);
						}
						else
						{	if(salary<=85000)
							{	tax=0.35;
								pay=36000*0.03+(144000-36000)*0.1+(300000-144000)*0.2+(420000-300000)*0.25+(660000-420000)*0.3+(12*salary-60000-660000)*0.35;
								printf("pay=%f",pay);
							}
							else
							{	if(salary>85000)
								{	tax=0.45;
									pay=36000*0.03+(144000-36000)*0.1+(300000-144000)*0.2+(420000-300000)*0.25+(660000-420000)*0.3+(960000-660000)*0.35+(12*salary-60000-960000)*0.45;
									printf("pay=%f",pay);
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}
					
					
					
					
					
