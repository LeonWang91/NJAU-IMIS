#include<stdio.h>
int main()
{
	int x,y=1,i=1;
	for(i=1;i<=9;i++)
	{
		x=2*(y+1);
		y=x;
	}
	printf("%d\n",x);
	return 0;
}