//��ӡ99�˷��ھ���
#include<stdio.h>
int main()
{
	int i=1,j=1;
	while(i<=9)
	{
		printf("%d\t",i);
		i=i+1;
	}
	printf("\n-----------------------------------------------------------------------\n");
	for(i=1;i<=9;i++)
		for(j=1;j<=9;j++)
			printf((j==9)?"%d\t\n":"%d\t",i*j);
	printf("\n");
	return 0;
}

