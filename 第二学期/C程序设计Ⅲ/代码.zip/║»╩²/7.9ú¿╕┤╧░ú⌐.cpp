//�ҳ�������������̨�㷨

#include<stdio.h>
#define N 5
int main()
{
	int max(int x,int y);
	int i,m,maxj;
	int a[N];
	printf("Please input the numbers:\n");
	for(i=0;i<N;i++)
	scanf("%d",&a[i]);
	printf("\n");
	m=a[0];
	maxj=0;							//Ҫ�г�ֵ
	for(i=1;i<N;i++)
		if(max(m,a[i])>m)			//˵��a[i]>m;
		{
			m=a[i];
			maxj=i;
		}
	printf("The largest number is %d and it is the %dth numbers\n",m,maxj+1);
	return 0;
}

int max(int x,int y)
{
	return (x>y)?x:y;
}
