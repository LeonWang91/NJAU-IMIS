#include<stdio.h>
int main()
{
	int age(int n);
	int k,a;
	printf("Please enter the number of students:\n");
	scanf("%d",&a);
	k=age(a);
	printf("The fifth student's age: %d\n",k);
	return 0;
}

int age(int n)
{
	int c;
	if(n==1)
		c=10;
	else
		c=age(n-1)+2;
	return c;
}

