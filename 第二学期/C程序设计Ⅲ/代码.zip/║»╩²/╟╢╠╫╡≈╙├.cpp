//������Ƕ�׵���
#include<stdio.h>
int main()
{
	int max4(int a,int b,int c,int d);
	int a,b,c,d;
	int max;
	printf("Please enter 4 numbers:\n");
	scanf("%d%d%d%d",&a,&b,&c,&d);
	printf("\n");
	max=max4(a,b,c,d);
	printf("The max is:%d\n",max);
	printf("\n");
	return 0;
}

int max4(int a,int b,int c,int d)
{
	int max2(int a,int b);
	int m;
	m=max2(a,b);
	m=max2(c,m);
	m=max2(d,m);
	return m;
}

int max2(int a,int b)
{
	return (a>b)?a:b;
}

