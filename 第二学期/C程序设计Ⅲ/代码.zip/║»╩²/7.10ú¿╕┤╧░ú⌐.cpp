#include<stdio.h>
#define N 5
int main()
{
	float average(float score[]);
	float a[N],aver;
	int i;
	printf("Please Input the scores of students:\n");
	for(i=0;i<N;i++)
		scanf("%f",&a[i]);
	printf("\n");
	aver=average(a);
	printf("The average score is: %5.2f\n",aver);
	return 0;
}

float average(float score[])
{
	int i;
	float sum=0,aver;
	for(i=0;i<N;i++)
		sum+=score[i];
	aver=sum/N;
	return aver;
}

