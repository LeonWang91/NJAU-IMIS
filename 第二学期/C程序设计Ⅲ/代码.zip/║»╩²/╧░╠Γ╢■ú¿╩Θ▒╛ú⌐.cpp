#include<stdio.h>
#include<math.h>
float x1,x2,disc,p,q;													//ȫ�ֱ���
int main()
{
	void caculate1(float,float);										//���ں�������ʱ����ʡ���β���
	void caculate2(float,float);
	void caculate3(float,float);
	float a,b,c;
	printf("Input a,b,c:");
	scanf("%f%f%f",&a,&b,&c);
	printf("equation: %5.2f*x*x+%5.2f*x+%5.2f=0\n",a,b,c);
	disc=b*b-4*a*c;
	printf("root:\n");
	if(disc>0)
	{
		caculate1(a,b);
		printf("x1=%f\tx2=%f\n",x1,x2);
	}
	else if(disc=0)
	{
		caculate2(a,b);
		printf("x1=%f\tx2=%f\n",x1,x2);
	}
	else
	{
		caculate3(a,b);
		printf("x1=%f+%fi\tx2=%f-%fi\n",p,q,p,q);
	}

void caculate1(float a,float b)
{
	x1=(-b+sqrt(disc))/(2*a);
	x2=(-b-sqrt(disc))/(2*a);
}

void caculate2(float a,float b)
{
	x1=x2=(-b)/(2*a);
}  

void caculate3(float a,float b)
{
	p=(-b)/(2*a);
	q=sqrt(-disc)/(2*a);
}


