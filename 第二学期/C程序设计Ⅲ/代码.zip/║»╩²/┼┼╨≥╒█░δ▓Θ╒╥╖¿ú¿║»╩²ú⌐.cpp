#include<stdio.h>
#define N 5
int i,j,k,temp1;
int aim,c,sign=0,loca,top=N-1,bott=0,mid;
int main()
{
	void sort(int array[]);
	void search(int array[],int m);
	int a[N];
	printf("Please enter the numbers:\n");
	for(i=0;i<N;i++)
		scanf("%d",&a[i]);
	sort(a);
	printf("The original order:\n");
	for(i=0;i<N;i++)
		printf("%4d",a[i]);
	printf("\n");
	printf("Please input the number you want to search:\n");
	scanf("%d",&aim);
	search(a,aim);
	return 0;
}


void sort(int array[])
{
	for(i=0;i<N-1;i++)
	{
		k=i;
		for(j=i+1;j<N;j++)		
			if(array[k]<array[j])			
				k=j;
		if(i!=k)
		{
			temp1=array[i];
			array[i]=array[k];
			array[k]=temp1;
		}
	}
}			

void search(int array[],int m)
{
	if(m>array[0]||aim<array[N-1])
		loca=-1;
	while((sign==0)&&bott<=top)
	{
		mid=(top+bott)/2;
		if(m==array[mid])
		{
			loca=mid;
			printf("%d has been found and it is the %dth numbers.\n",m,loca+1);
			sign=1;
		}
		else if(m<array[mid])
			bott=mid+1;
		else
			top=mid-1;
	}
	if(sign==0||loca==-1)
		printf("The number is not found\n");
	printf("\n");
}
