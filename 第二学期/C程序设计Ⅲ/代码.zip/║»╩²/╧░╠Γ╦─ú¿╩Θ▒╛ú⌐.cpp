#include<stdio.h>
int array[3][3];						//�ⲿ��������������
int main()
{
	void convert(int array[][3]);
	int i,j;
	printf("Input array:\n");
	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
			scanf("%d",&array[i][j]);
	printf("\nOriginal array:\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
			printf("%4d",array[i][j]);
		printf("\n");
	}
	convert(array);
	printf("convert array:\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
			printf("%4d",array[i][j]);
		printf("\n");
	}
	return 0;
}

void convert(int array[][3])
{
	int i,j,t;
	for(i=0;i<3;i++)
	{
		for(j=i+1;j<3;j++)
		{
			t=array[i][j];
			array[i][j]=array[j][i];
			array[j][i]=t;
		}
	}
}




