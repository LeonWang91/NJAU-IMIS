#include<stdio.h>
#include<string.h>
#define N 10
int main()
{
	void input(int num[],char name[N][8]);					//һ�������ɶ���ַ���ɣ��ʼ�������Ӧ�ö�ά�����ʾ
	void sort(int num[],char name[N][8]);
	void search(int n,int num[],char name[N][8]);
	int num[N];
	int number,flag=1;
	char name[N][8],c;
	input(num,name);										//��һ������
	sort(num,name);											//�ڶ�������
	while(flag==1)											//�������۰����
	{
		printf("\ninput number to look for:");
		scanf("%d",&number);
		search(number,num,name);
		printf("Continue or not?(Y/N)");
		getchar();
		c=getchar();
		if(c=='N'||c=='n')
			flag=0;
	}
	return 0;
}

void input(int num[],char name[N][8])
{
	int i;
	for(i=0;i<N;i++)
	{
		printf("No.%d:",i);
		scanf("%d",&num[i]);
		getchar();
		printf("input name:");
		gets(name[i]);
	}
}

void sort(int num[],char name[N][8])
{
	int i,j,min,temp1;
	char temp2[8];
	for(i=0;i<N-1;i++)
	{
		min=i;
		for(j=i+1;j<N;j++)
		{
			if(num[min]>num[j])		//��С������
				min=j;
		}
		temp1=num[i];				//������ͬ������ͬʱ��ֵ
		strcpy(temp2,name[i]);
		num[i]=num[min];
		strcpy(name[i],name[min]);
		num[min]=temp1;
		strcpy(name[min],temp2);
	}

void search(int n,int num[],char name[N][8])
{
	int top=N-1,bott=0,loca,sign=0,mid;
	if((n>num[N-1])||(n<num[0]))
		loca=-1;
	while((!sign)&&bott<=top)
	{
		mid=(top+bott)/2;
		if(n==num[mid])
		{
			loca=mid;
			printf("No.%d,his name is %s.\n",n,name[loca])
			sign=1;
		}
		else if(n<num[mid])
			top=mid-1;
		else
			bott=mid+1;
	}
	if((!sign)||loca==-1)
		printf("%d has not been found.\n",n);
}
