//�õݹ鷨��n!

#include<stdio.h>
int main()
{
	float fac(int n);
	int i;
	printf("Please enter a number:\n");
	scanf("%d",&i);
	printf("%d!=%f\n",i,fac(i));
	return 0;
}

float fac(int n)
{
	float f;
	if(n<0)
		printf("Error!");
	else if(n==0 || n==1)
		f=1;
	else
		f=fac(n-1)*n;
	return f;
}