#include<stdio.h>
#define N 5 
#define M 6
int main()
{
	float average(float array[],int n);
	float score1[N]={99,89,79,69,59};
	float score2[M]={98,88,78,68,58,48};
	printf("The first class's score is:%5.2f\n",average(score1,N));
	printf("The second class's score is:%5.2f\n",average(score2,M));
	return 0;
}

float average(float array[],int n)
{
	int i;
	float sum=0,aver;					//sumһ��Ҫ��ֵ
	for(i=0;i<n;i++)
		sum+=array[i];
	aver=sum/n;
	return aver;
}

	

