#include<stdio.h>
#define N 6
int i,j,k,t;
int m;
int main()
{
	void sort(int array[]);
	void insert(int array[],int n);
	int a[N];
	printf("Please enter the numbers:\n");
	for(i=0;i<N-1;i++)
		scanf("%d",&a[i]);
	printf("\n");
	printf("The original numbers:\n");
	for(i=0;i<N-1;i++)
		printf("%4d",a[i]);
	printf("\n");
	sort(a);
	printf("The sorted numbers:\n");
	for(i=0;i<N-1;i++)
		printf("%4d",a[i]);
	printf("\n");
	printf("Insert a number:\n");
	scanf("%d",&m);
	insert(a,m);
	printf("The insertedly sorted numbers:\n");
	for(i=0;i<N;i++)
		printf("%4d",a[i]);
	printf("\n");
	return 0;
}

void sort(int array[])
{
	for(i=0;i<N-2;i++)
	{
		k=i;
		for(j=i+1;j<N-1;j++)
			if(array[k]<array[j])								
				k=j;
		if(i!=k)
		{
			t=array[i];
			array[i]=array[k];
			array[k]=t;
		}
	}
}


void insert(int array[],int n)
{
	if(n<=array[N-2])
		array[N-1]=n;
	else
		for(i=N-2;i>=0;i--)
			if(n>array[i])
			{
				array[i+1]=array[i];
				array[i]=m;
			}
}
