#include<stdio.h>
int main()
{
	float x;
	int y;
	printf("������һ��xֵ:\n");
	scanf("%f",&x);
	if(x>0)
		y=1;
	else
		if(x=0)
			y=0;
		else
			y=-1;
		printf("%d\n",y);

	/*if(x>=0)
		if(x>0)
			y=1;
		else
			y=0;
	else
		y=-1;
	printf("%d\n",y);*/
	return 0;
}