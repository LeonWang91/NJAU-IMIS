#include<stdio.h>
int main()
{
	float fac(float n);
	int m;
	float n;
	printf("Input a number:\n");
	scanf("%d",&m);
	n=fac(m);
	printf("Outcome:\n");
	printf("%d!=%f\n",m,n);
	return 0;
}

float fac(float n)
{
	float f;
	if(n<=0)
		printf("Error!");
	else if(n==0||n==1)
		f=1;
	else
		f=n*fac(n-1);			//fac(n)����>fac(n-1)*n
	return f;
}
