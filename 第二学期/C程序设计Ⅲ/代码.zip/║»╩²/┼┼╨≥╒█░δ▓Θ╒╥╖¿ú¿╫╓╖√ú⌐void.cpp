#include<stdio.h>
#define N 5
int i,j;
char t,c;
int sign=0,top=N-1,bott=0,mid,loca;
int main()
{
	void sort(char string[]);
	void search(char string[],char n);
	char str[N];
	printf("Please enter the data:\n");
	for(i=0;i<N;i++)
	{
		scanf("%c",&str[i]);
		getchar();
	}
	printf("\n");
	printf("The original order:\n");
	for(i=0;i<N;i++)
		printf("%4c",str[i]);
	printf("\n");
	sort(str);
	printf("The sorted order:\n");
	for(i=0;i<N;i++)
		printf("%4c",str[i]);
	printf("\n");
	printf("Please enter the letter you want to search:\n");
	scanf("%c",&c);
	search(str,c);
	return 0;
}

void sort(char string[])
{
	for(i=0;i<N-1;i++)
		for(j=0;j<N-i-1;i++)
			if(string[i]>string[i+1])		//��С��������
			{
				t=string[i];
				string[i]=string[i+1];
				string[i+1]=t;
			}
}


void search(char string[],char n)
{
	if(n>string[N-1]||n<string[0])
		loca=-1;
	while((!sign)&&bott<=top)
	{
		mid=(top+bott)/2;
		if(n==string[mid])
		{
			loca=mid;
			printf("%c has been found and it is the %dth letters\n",n,loca+1);
			sign=1;
		}
		else if(n>string[mid])
			bott=mid+1;
		else
			top=mid-1;
	}
	if((!sign)||loca==-1)
		printf("This letter can not be found!\n");
}


	
