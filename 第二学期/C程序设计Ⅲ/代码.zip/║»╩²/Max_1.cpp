#include<stdio.h>
int main()
{
	int max(int x,int y,int z);
	int a,b,c,d;
	scanf("%d %d %d",&a,&b,&c);
	d=max(a,b,c);
	printf("max=%d\n",d);
	return 0;
}
int max(int x,int y,int z)
{
	int a;
	if(x>y,x>z)a=x;
	if(y>x,y>z)a=y;
	else a=z;
	return(a);
}
