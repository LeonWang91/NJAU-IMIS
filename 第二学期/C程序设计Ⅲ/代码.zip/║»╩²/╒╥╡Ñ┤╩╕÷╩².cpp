#include<stdio.h>
#include<string.h>
int main()
{
	char str[80];
	int i,num=0,word=0;
	printf("Please enter a text:\n");
	gets(str);
	printf("\nThe text is:%s\n",str);
	for(i=0;i<=strlen(str);i++)
	{
		if(str[i]==' ')		//�ո�������һ���µĵ��ʣ�******"=="********
			word=0;
		else
			if(word==0)
			{
				num++;
				word=1;
			}
	}
	printf("There are %d words in this text.\n",num);
	return 0;
}



