//ð������(�Ӵ�С)
#include<stdio.h>
#define N 5
int i,j,t;
int main()
{
	void sort(int array[]);
	int a[N];
	printf("Please enter an array:\n");
	for(i=0;i<N;i++)
		scanf("%d",&a[i]);
	printf("The original order:\n");
	for(i=0;i<N;i++)
		printf("%4d",a[i]);
	printf("\n");
	sort(a);
	printf("The sorted order:\n");
	for(i=0;i<N;i++)
		printf("%4d",a[i]);
	printf("\n");
	return 0;
}


void sort(int array[])
{
	for(j=0;j<N-1;j++)
	{
		for(i=0;i<N-j-1;i++)
		{
			if(array[i]<array[i+1])
			{
				t=array[i];
				array[i]=array[i+1];
				array[i+1]=t;
			}
		}
	}
}





