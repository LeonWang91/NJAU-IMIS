#include<stdio.h>
int main()
{
	int prime(int);
	int n;
	printf("Input an integer:");
	scanf("%d",&n);
	if(prime(n))								//���prime(n)=1��Ϊ�棬ִ�к�һ��
		printf("%d is a prime.\n",n);
	else
		printf("%d is not a prime\n",n);
	return 0;
}

int prime(int m)
{
	int flag=1,i;
	for(i=2;i<m&&flag==1;i++)
		if(m%i==0)
			flag=0;
	return flag;
}