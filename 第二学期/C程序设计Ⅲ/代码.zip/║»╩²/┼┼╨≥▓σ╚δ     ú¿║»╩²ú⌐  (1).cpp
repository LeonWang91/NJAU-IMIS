//����ʮ���������Ӵ�С�����������в���һ��������ԭ����˳������

#include<stdio.h>
#define N 6
int i,j,k,temp1,m,temp2;
int main()
{
	void sort(int array1[]);
	void insert(int array2[],int n);
	int a[N];
	int i,j,k,temp1;
	int m,temp2;
	printf("Please enter the numbers:\n");
	for(i=0;i<N-1;i++)
		scanf("%d",&a[i]);
	sort(a);
	printf("The original order:\n");
	for(i=0;i<N-1;i++)
		printf("%4d",a[i]);
	printf("\n");
	printf("Please enter another number:\n");
	scanf("%d",&m);
	insert(a,m);
	printf("The sorted order:\n");
	for(i=0;i<N;i++)
		printf("%4d",a[i]);
	printf("\n");
	return 0;
}

void sort(int array1[])
{
	for(i=0;i<N-2;i++)
	{
		k=i;
		for(j=i+1;j<N-1;j++)	
			if(array1[k]<array1[j])
				k=j;
		if(i!=k)
		{
			temp1=array1[i];
			array1[i]=array1[k];
			array1[k]=temp1;
		}
	}
}


void insert(int array2[],int n)
{

	if(n<=array2[N-2])
		array2[N-1]=n;
	else
		for(i=N-2;i>=0;i--)				
		{
			if(n>array2[i])
			{
				array2[i+1]=array2[i];
				array2[i]=n;
			}
		}
}
