#include<stdio.h>
#define N 5
int i,j,k,temp1;
int aim,c,sign,loca,top,bott,mid,flag=1;
int main()
{
	int a[N];
	printf("Please enter the numbers:\n");
	for(i=0;i<N;i++)
		scanf("%d",&a[i]);
	for(i=0;i<N-1;i++)
	{
		k=i;
		for(j=i+1;j<N;j++)		//***ע��j�ĳ�ֵ�ͷ�Χ
			if(a[k]<a[j])		//�Ӵ�С	
				k=j;
		if(i!=k)
		{
			temp1=a[i];
			a[i]=a[k];
			a[k]=temp1;
		}
	}
	printf("The original order:\n");
	for(i=0;i<N;i++)
		printf("%4d",a[i]);
	printf("\n");
	while(flag)
	{
		printf("Please input the number you want to search:\n");
		scanf("%d",&aim);
		getchar();
		sign=0;								//�˴�������ֵҪ����ѭ����������ֵ��ı�
		top=N-1;
		bott=0;
		flag=1;
		if(aim>a[0]||aim<a[N-1])
			loca=-1;
		while((sign==0)&&bott<=top)
		{
			mid=(top+bott)/2;
			if(aim==a[mid])
			{
				loca=mid;
				printf("%d has been found and it is the %dth numbers.\n",aim,loca+1);
				sign=1;
			}
			else if(aim<a[mid])
				bott=mid+1;
			else
				top=mid-1;
		}
	
		if(sign==0||loca==-1)
			printf("The number is not found\n");
		printf("Do you want to search aother number?(Y/N)");
		scanf("%c",&c);
		if(c=='N'||c=='n')
			flag=0;
		printf("\n");
	}
	return 0;
}
				